PSuite FOREVER 8 — RyzenDIY

Названия файлов — на русском. Содержимое промтов — на английском.

00 — MASTER CONTEXT: давать агенту вместе с его ролью.
01 — ChatGPT: понимает твою идею и решает, кому дать задачу.
02 — Claude: основной разработчик крупных фич и архитектуры.
03 — Codex: точечный ремонт после твоего реального теста.
04 — Windows expert: спорные/опасные твики.(тоже к ChatGPT)
05 — Benchmark specialist: FPS, frametime, latency, Rust.(тоже к ChatGPT)
06 — Release/architecture reviewer: перед важной версией.
07 - COPILOT:редкий независимый аудит всего проекта.
08 — Gemini: редкий независимый аудит всего проекта.(запас)

Обязательной AI-цепочки нет.
Обычный путь: RyzenDIY -> ChatGPT -> Claude -> RyzenDIY test.
Если тест сломан: RyzenDIY -> ChatGPT -> Codex или Claude, в зависимости от причины.
Специалисты используются только по необходимости.
