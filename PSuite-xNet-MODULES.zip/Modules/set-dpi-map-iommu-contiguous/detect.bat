@echo off
setlocal EnableExtensions EnableDelayedExpansion
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v DpiMapIommuContiguous 2^>nul ^| findstr /i "DpiMapIommuContiguous"') do set "V=%%a"
set "V=!V: =!" & set "V=!V:0x=!"
if "!V!"=="1" (echo {"success":true,"state":"Applied","details":"DpiMapIommuContiguous=1"}) else (echo {"success":true,"state":"NotApplied","details":"!V!"})
endlocal & exit /b 0
