@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
if not exist "%~1" mkdir "%~1" >nul 2>&1
set "OLD=NOT_EXIST"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v DpiMapIommuContiguous 2^>nul ^| findstr /i "DpiMapIommuContiguous"') do set "OLD=%%a"
echo !OLD!> "%~1\dpi.txt"
reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v DpiMapIommuContiguous /t REG_DWORD /d 1 /f >nul 2>&1
echo {"success":true,"requiresRestart":true,"details":"DpiMapIommuContiguous=1"}
endlocal & exit /b 0
