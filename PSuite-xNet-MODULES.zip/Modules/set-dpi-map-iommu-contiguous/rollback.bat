@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
set /p OLD=<"%~1\dpi.txt"
set "OLD=!OLD: =!"
if /i "!OLD!"=="NOT_EXIST" (reg delete "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v DpiMapIommuContiguous /f >nul 2>&1) else (set "OLD=!OLD:0x=!" & reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v DpiMapIommuContiguous /t REG_DWORD /d !OLD! /f >nul 2>&1)
echo {"success":true,"details":"restored"}
endlocal & exit /b 0
