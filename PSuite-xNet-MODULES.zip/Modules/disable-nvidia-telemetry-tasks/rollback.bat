@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
set "LIST=%~1\tasks.txt"
if not exist "%LIST%" (echo {"success":false,"details":"Capture list missing"} & endlocal & exit /b 0)
for /f "usebackq delims=" %%T in ("%LIST%") do (
  schtasks /Change /Enable /TN "%%T" >nul 2>&1
)
echo {"success":true,"details":"NVIDIA tasks re-enabled from capture"}
endlocal & exit /b 0
