@echo off
setlocal
schtasks /Query /TN "NvTmMon_{B2FE1952-0186-46C3-BAEC-A80AA35AC5B8}" 2>nul | findstr /i "Disabled" >nul
if not errorlevel 1 (echo {"success":true,"state":"Applied","details":"NvTmMon disabled"} & endlocal & exit /b 0)
echo {"success":true,"state":"NotApplied","details":"tasks enabled or missing"}
endlocal & exit /b 0
