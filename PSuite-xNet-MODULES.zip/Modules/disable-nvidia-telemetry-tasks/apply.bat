@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
if not exist "%~1" mkdir "%~1" >nul 2>&1
set "LIST=%~1\tasks.txt"
if exist "%LIST%" del /f /q "%LIST%" >nul 2>&1
for %%T in (
 "NvDriverUpdateCheckDaily_{B2FE1952-0186-46C3-BAEC-A80AA35AC5B8}"
 "NVIDIA GeForce Experience SelfUpdate_{B2FE1952-0186-46C3-BAEC-A80AA35AC5B8}"
 "NvTmRep_CrashReport1_{B2FE1952-0186-46C3-BAEC-A80AA35AC5B8}"
 "NvTmRep_CrashReport2_{B2FE1952-0186-46C3-BAEC-A80AA35AC5B8}"
 "NvTmRep_CrashReport3_{B2FE1952-0186-46C3-BAEC-A80AA35AC5B8}"
 "NvTmRep_CrashReport4_{B2FE1952-0186-46C3-BAEC-A80AA35AC5B8}"
 "NvTmMon_{B2FE1952-0186-46C3-BAEC-A80AA35AC5B8}"
 "NvTmRep_{B2FE1952-0186-46C3-BAEC-A80AA35AC5B8}"
 "NvTmRepOnLogon_{B2FE1952-0186-46C3-BAEC-A80AA35AC5B8}"
) do (
  schtasks /Query /TN %%T >nul 2>&1
  if not errorlevel 1 (
    echo %%~T>> "%LIST%"
    schtasks /Change /Disable /TN %%T >nul 2>&1
  )
)
echo {"success":true,"requiresRestart":false,"details":"NVIDIA tasks disabled if present"}
endlocal & exit /b 0
