@echo off
bcdedit /enum {current} 2>nul | findstr /i "disabledynamictick" | findstr /i "Yes" >nul
if not errorlevel 1 (echo {"success":true,"state":"Applied","details":"disabledynamictick Yes"}) else (echo {"success":true,"state":"NotApplied","details":"default or No"})
exit /b 0
