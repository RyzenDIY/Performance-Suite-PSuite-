@echo off
setlocal
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & exit /b 0)
if not exist "%~1" mkdir "%~1" >nul 2>&1
bcdedit /enum {current} 2>nul | findstr /i "disabledynamictick" > "%~1\bcd-dyn.txt"
bcdedit /set disabledynamictick Yes >nul 2>&1
if errorlevel 1 (echo {"success":false,"details":"bcdedit failed — run as admin"} & endlocal & exit /b 0)
echo {"success":true,"requiresRestart":true,"details":"disabledynamictick Yes"}
endlocal & exit /b 0
