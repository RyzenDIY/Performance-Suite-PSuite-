@echo off
setlocal
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & exit /b 0)
bcdedit /deletevalue disabledynamictick >nul 2>&1
echo {"success":true,"details":"disabledynamictick deleted (Windows default)"}
endlocal & exit /b 0
