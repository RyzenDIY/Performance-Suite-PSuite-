@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "OK=1"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\SCardSvr" /v Start 2^>nul ^| findstr /i "Start"') do set "ST_SCardSvr=%%a"
set "ST_SCardSvr=!ST_SCardSvr: =!" & set "ST_SCardSvr=!ST_SCardSvr:0x=!"
if not "!ST_SCardSvr!"=="4" set "OK=0"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\ScDeviceEnum" /v Start 2^>nul ^| findstr /i "Start"') do set "ST_ScDeviceEnum=%%a"
set "ST_ScDeviceEnum=!ST_ScDeviceEnum: =!" & set "ST_ScDeviceEnum=!ST_ScDeviceEnum:0x=!"
if not "!ST_ScDeviceEnum!"=="4" set "OK=0"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\SCPolicySvc" /v Start 2^>nul ^| findstr /i "Start"') do set "ST_SCPolicySvc=%%a"
set "ST_SCPolicySvc=!ST_SCPolicySvc: =!" & set "ST_SCPolicySvc=!ST_SCPolicySvc:0x=!"
if not "!ST_SCPolicySvc!"=="4" set "OK=0"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\CertPropSvc" /v Start 2^>nul ^| findstr /i "Start"') do set "ST_CertPropSvc=%%a"
set "ST_CertPropSvc=!ST_CertPropSvc: =!" & set "ST_CertPropSvc=!ST_CertPropSvc:0x=!"
if not "!ST_CertPropSvc!"=="4" set "OK=0"
if "!OK!"=="1" (echo {"success":true,"state":"Applied","details":"all=4"}) else (echo {"success":true,"state":"NotApplied","details":"partial"})
endlocal & exit /b 0
