@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
if not exist "%~1" mkdir "%~1" >nul 2>&1
set "OLD_SCardSvr=3"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\SCardSvr" /v Start 2^>nul ^| findstr /i "Start"') do set "OLD_SCardSvr=%%a"
set "OLD_SCardSvr=!OLD_SCardSvr: =!" & set "OLD_SCardSvr=!OLD_SCardSvr:0x=!"
echo !OLD_SCardSvr!> "%~1\SCardSvr.txt"
sc stop SCardSvr >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\SCardSvr" /v Start /t REG_DWORD /d 4 /f >nul 2>&1
set "OLD_ScDeviceEnum=3"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\ScDeviceEnum" /v Start 2^>nul ^| findstr /i "Start"') do set "OLD_ScDeviceEnum=%%a"
set "OLD_ScDeviceEnum=!OLD_ScDeviceEnum: =!" & set "OLD_ScDeviceEnum=!OLD_ScDeviceEnum:0x=!"
echo !OLD_ScDeviceEnum!> "%~1\ScDeviceEnum.txt"
sc stop ScDeviceEnum >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\ScDeviceEnum" /v Start /t REG_DWORD /d 4 /f >nul 2>&1
set "OLD_SCPolicySvc=3"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\SCPolicySvc" /v Start 2^>nul ^| findstr /i "Start"') do set "OLD_SCPolicySvc=%%a"
set "OLD_SCPolicySvc=!OLD_SCPolicySvc: =!" & set "OLD_SCPolicySvc=!OLD_SCPolicySvc:0x=!"
echo !OLD_SCPolicySvc!> "%~1\SCPolicySvc.txt"
sc stop SCPolicySvc >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\SCPolicySvc" /v Start /t REG_DWORD /d 4 /f >nul 2>&1
set "OLD_CertPropSvc=3"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\CertPropSvc" /v Start 2^>nul ^| findstr /i "Start"') do set "OLD_CertPropSvc=%%a"
set "OLD_CertPropSvc=!OLD_CertPropSvc: =!" & set "OLD_CertPropSvc=!OLD_CertPropSvc:0x=!"
echo !OLD_CertPropSvc!> "%~1\CertPropSvc.txt"
sc stop CertPropSvc >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\CertPropSvc" /v Start /t REG_DWORD /d 4 /f >nul 2>&1
echo {"success":true,"requiresRestart":false,"details":"services disabled"}
endlocal & exit /b 0
