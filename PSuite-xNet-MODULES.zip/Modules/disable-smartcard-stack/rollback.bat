@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
if exist "%~1\SCardSvr.txt" (set /p S_SCardSvr=<"%~1\SCardSvr.txt") else (set "S_SCardSvr=3")
set "S_SCardSvr=!S_SCardSvr: =!" & set "S_SCardSvr=!S_SCardSvr:0x=!"
if "!S_SCardSvr!"=="" set "S_SCardSvr=3"
reg add "HKLM\SYSTEM\CurrentControlSet\Services\SCardSvr" /v Start /t REG_DWORD /d !S_SCardSvr! /f >nul 2>&1
if exist "%~1\ScDeviceEnum.txt" (set /p S_ScDeviceEnum=<"%~1\ScDeviceEnum.txt") else (set "S_ScDeviceEnum=3")
set "S_ScDeviceEnum=!S_ScDeviceEnum: =!" & set "S_ScDeviceEnum=!S_ScDeviceEnum:0x=!"
if "!S_ScDeviceEnum!"=="" set "S_ScDeviceEnum=3"
reg add "HKLM\SYSTEM\CurrentControlSet\Services\ScDeviceEnum" /v Start /t REG_DWORD /d !S_ScDeviceEnum! /f >nul 2>&1
if exist "%~1\SCPolicySvc.txt" (set /p S_SCPolicySvc=<"%~1\SCPolicySvc.txt") else (set "S_SCPolicySvc=3")
set "S_SCPolicySvc=!S_SCPolicySvc: =!" & set "S_SCPolicySvc=!S_SCPolicySvc:0x=!"
if "!S_SCPolicySvc!"=="" set "S_SCPolicySvc=3"
reg add "HKLM\SYSTEM\CurrentControlSet\Services\SCPolicySvc" /v Start /t REG_DWORD /d !S_SCPolicySvc! /f >nul 2>&1
if exist "%~1\CertPropSvc.txt" (set /p S_CertPropSvc=<"%~1\CertPropSvc.txt") else (set "S_CertPropSvc=3")
set "S_CertPropSvc=!S_CertPropSvc: =!" & set "S_CertPropSvc=!S_CertPropSvc:0x=!"
if "!S_CertPropSvc!"=="" set "S_CertPropSvc=3"
reg add "HKLM\SYSTEM\CurrentControlSet\Services\CertPropSvc" /v Start /t REG_DWORD /d !S_CertPropSvc! /f >nul 2>&1
echo {"success":true,"details":"services restored"}
endlocal & exit /b 0
