@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
if exist "%~1\HvHost.txt" (set /p S_HvHost=<"%~1\HvHost.txt") else (set "S_HvHost=3")
set "S_HvHost=!S_HvHost: =!" & set "S_HvHost=!S_HvHost:0x=!"
if "!S_HvHost!"=="" set "S_HvHost=3"
reg add "HKLM\SYSTEM\CurrentControlSet\Services\HvHost" /v Start /t REG_DWORD /d !S_HvHost! /f >nul 2>&1
if exist "%~1\vmickvpexchange.txt" (set /p S_vmickvpexchange=<"%~1\vmickvpexchange.txt") else (set "S_vmickvpexchange=3")
set "S_vmickvpexchange=!S_vmickvpexchange: =!" & set "S_vmickvpexchange=!S_vmickvpexchange:0x=!"
if "!S_vmickvpexchange!"=="" set "S_vmickvpexchange=3"
reg add "HKLM\SYSTEM\CurrentControlSet\Services\vmickvpexchange" /v Start /t REG_DWORD /d !S_vmickvpexchange! /f >nul 2>&1
if exist "%~1\vmicguestinterface.txt" (set /p S_vmicguestinterface=<"%~1\vmicguestinterface.txt") else (set "S_vmicguestinterface=3")
set "S_vmicguestinterface=!S_vmicguestinterface: =!" & set "S_vmicguestinterface=!S_vmicguestinterface:0x=!"
if "!S_vmicguestinterface!"=="" set "S_vmicguestinterface=3"
reg add "HKLM\SYSTEM\CurrentControlSet\Services\vmicguestinterface" /v Start /t REG_DWORD /d !S_vmicguestinterface! /f >nul 2>&1
if exist "%~1\vmicshutdown.txt" (set /p S_vmicshutdown=<"%~1\vmicshutdown.txt") else (set "S_vmicshutdown=3")
set "S_vmicshutdown=!S_vmicshutdown: =!" & set "S_vmicshutdown=!S_vmicshutdown:0x=!"
if "!S_vmicshutdown!"=="" set "S_vmicshutdown=3"
reg add "HKLM\SYSTEM\CurrentControlSet\Services\vmicshutdown" /v Start /t REG_DWORD /d !S_vmicshutdown! /f >nul 2>&1
if exist "%~1\vmicheartbeat.txt" (set /p S_vmicheartbeat=<"%~1\vmicheartbeat.txt") else (set "S_vmicheartbeat=3")
set "S_vmicheartbeat=!S_vmicheartbeat: =!" & set "S_vmicheartbeat=!S_vmicheartbeat:0x=!"
if "!S_vmicheartbeat!"=="" set "S_vmicheartbeat=3"
reg add "HKLM\SYSTEM\CurrentControlSet\Services\vmicheartbeat" /v Start /t REG_DWORD /d !S_vmicheartbeat! /f >nul 2>&1
if exist "%~1\vmicvmsession.txt" (set /p S_vmicvmsession=<"%~1\vmicvmsession.txt") else (set "S_vmicvmsession=3")
set "S_vmicvmsession=!S_vmicvmsession: =!" & set "S_vmicvmsession=!S_vmicvmsession:0x=!"
if "!S_vmicvmsession!"=="" set "S_vmicvmsession=3"
reg add "HKLM\SYSTEM\CurrentControlSet\Services\vmicvmsession" /v Start /t REG_DWORD /d !S_vmicvmsession! /f >nul 2>&1
if exist "%~1\vmicrdv.txt" (set /p S_vmicrdv=<"%~1\vmicrdv.txt") else (set "S_vmicrdv=3")
set "S_vmicrdv=!S_vmicrdv: =!" & set "S_vmicrdv=!S_vmicrdv:0x=!"
if "!S_vmicrdv!"=="" set "S_vmicrdv=3"
reg add "HKLM\SYSTEM\CurrentControlSet\Services\vmicrdv" /v Start /t REG_DWORD /d !S_vmicrdv! /f >nul 2>&1
if exist "%~1\vmictimesync.txt" (set /p S_vmictimesync=<"%~1\vmictimesync.txt") else (set "S_vmictimesync=3")
set "S_vmictimesync=!S_vmictimesync: =!" & set "S_vmictimesync=!S_vmictimesync:0x=!"
if "!S_vmictimesync!"=="" set "S_vmictimesync=3"
reg add "HKLM\SYSTEM\CurrentControlSet\Services\vmictimesync" /v Start /t REG_DWORD /d !S_vmictimesync! /f >nul 2>&1
if exist "%~1\vmicvss.txt" (set /p S_vmicvss=<"%~1\vmicvss.txt") else (set "S_vmicvss=3")
set "S_vmicvss=!S_vmicvss: =!" & set "S_vmicvss=!S_vmicvss:0x=!"
if "!S_vmicvss!"=="" set "S_vmicvss=3"
reg add "HKLM\SYSTEM\CurrentControlSet\Services\vmicvss" /v Start /t REG_DWORD /d !S_vmicvss! /f >nul 2>&1
echo {"success":true,"details":"services restored"}
endlocal & exit /b 0
