@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
if not exist "%~1" mkdir "%~1" >nul 2>&1
set "OLD_HvHost=3"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\HvHost" /v Start 2^>nul ^| findstr /i "Start"') do set "OLD_HvHost=%%a"
set "OLD_HvHost=!OLD_HvHost: =!" & set "OLD_HvHost=!OLD_HvHost:0x=!"
echo !OLD_HvHost!> "%~1\HvHost.txt"
sc stop HvHost >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\HvHost" /v Start /t REG_DWORD /d 4 /f >nul 2>&1
set "OLD_vmickvpexchange=3"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\vmickvpexchange" /v Start 2^>nul ^| findstr /i "Start"') do set "OLD_vmickvpexchange=%%a"
set "OLD_vmickvpexchange=!OLD_vmickvpexchange: =!" & set "OLD_vmickvpexchange=!OLD_vmickvpexchange:0x=!"
echo !OLD_vmickvpexchange!> "%~1\vmickvpexchange.txt"
sc stop vmickvpexchange >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\vmickvpexchange" /v Start /t REG_DWORD /d 4 /f >nul 2>&1
set "OLD_vmicguestinterface=3"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\vmicguestinterface" /v Start 2^>nul ^| findstr /i "Start"') do set "OLD_vmicguestinterface=%%a"
set "OLD_vmicguestinterface=!OLD_vmicguestinterface: =!" & set "OLD_vmicguestinterface=!OLD_vmicguestinterface:0x=!"
echo !OLD_vmicguestinterface!> "%~1\vmicguestinterface.txt"
sc stop vmicguestinterface >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\vmicguestinterface" /v Start /t REG_DWORD /d 4 /f >nul 2>&1
set "OLD_vmicshutdown=3"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\vmicshutdown" /v Start 2^>nul ^| findstr /i "Start"') do set "OLD_vmicshutdown=%%a"
set "OLD_vmicshutdown=!OLD_vmicshutdown: =!" & set "OLD_vmicshutdown=!OLD_vmicshutdown:0x=!"
echo !OLD_vmicshutdown!> "%~1\vmicshutdown.txt"
sc stop vmicshutdown >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\vmicshutdown" /v Start /t REG_DWORD /d 4 /f >nul 2>&1
set "OLD_vmicheartbeat=3"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\vmicheartbeat" /v Start 2^>nul ^| findstr /i "Start"') do set "OLD_vmicheartbeat=%%a"
set "OLD_vmicheartbeat=!OLD_vmicheartbeat: =!" & set "OLD_vmicheartbeat=!OLD_vmicheartbeat:0x=!"
echo !OLD_vmicheartbeat!> "%~1\vmicheartbeat.txt"
sc stop vmicheartbeat >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\vmicheartbeat" /v Start /t REG_DWORD /d 4 /f >nul 2>&1
set "OLD_vmicvmsession=3"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\vmicvmsession" /v Start 2^>nul ^| findstr /i "Start"') do set "OLD_vmicvmsession=%%a"
set "OLD_vmicvmsession=!OLD_vmicvmsession: =!" & set "OLD_vmicvmsession=!OLD_vmicvmsession:0x=!"
echo !OLD_vmicvmsession!> "%~1\vmicvmsession.txt"
sc stop vmicvmsession >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\vmicvmsession" /v Start /t REG_DWORD /d 4 /f >nul 2>&1
set "OLD_vmicrdv=3"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\vmicrdv" /v Start 2^>nul ^| findstr /i "Start"') do set "OLD_vmicrdv=%%a"
set "OLD_vmicrdv=!OLD_vmicrdv: =!" & set "OLD_vmicrdv=!OLD_vmicrdv:0x=!"
echo !OLD_vmicrdv!> "%~1\vmicrdv.txt"
sc stop vmicrdv >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\vmicrdv" /v Start /t REG_DWORD /d 4 /f >nul 2>&1
set "OLD_vmictimesync=3"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\vmictimesync" /v Start 2^>nul ^| findstr /i "Start"') do set "OLD_vmictimesync=%%a"
set "OLD_vmictimesync=!OLD_vmictimesync: =!" & set "OLD_vmictimesync=!OLD_vmictimesync:0x=!"
echo !OLD_vmictimesync!> "%~1\vmictimesync.txt"
sc stop vmictimesync >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\vmictimesync" /v Start /t REG_DWORD /d 4 /f >nul 2>&1
set "OLD_vmicvss=3"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\vmicvss" /v Start 2^>nul ^| findstr /i "Start"') do set "OLD_vmicvss=%%a"
set "OLD_vmicvss=!OLD_vmicvss: =!" & set "OLD_vmicvss=!OLD_vmicvss:0x=!"
echo !OLD_vmicvss!> "%~1\vmicvss.txt"
sc stop vmicvss >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\vmicvss" /v Start /t REG_DWORD /d 4 /f >nul 2>&1
echo {"success":true,"requiresRestart":false,"details":"services disabled"}
endlocal & exit /b 0
