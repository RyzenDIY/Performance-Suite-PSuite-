@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
if exist "%~1\RasAcd.txt" (set /p S_RasAcd=<"%~1\RasAcd.txt") else (set "S_RasAcd=3")
set "S_RasAcd=!S_RasAcd: =!" & set "S_RasAcd=!S_RasAcd:0x=!"
if "!S_RasAcd!"=="" set "S_RasAcd=3"
reg add "HKLM\SYSTEM\CurrentControlSet\Services\RasAcd" /v Start /t REG_DWORD /d !S_RasAcd! /f >nul 2>&1
if exist "%~1\Rasl2tp.txt" (set /p S_Rasl2tp=<"%~1\Rasl2tp.txt") else (set "S_Rasl2tp=3")
set "S_Rasl2tp=!S_Rasl2tp: =!" & set "S_Rasl2tp=!S_Rasl2tp:0x=!"
if "!S_Rasl2tp!"=="" set "S_Rasl2tp=3"
reg add "HKLM\SYSTEM\CurrentControlSet\Services\Rasl2tp" /v Start /t REG_DWORD /d !S_Rasl2tp! /f >nul 2>&1
if exist "%~1\RasPppoe.txt" (set /p S_RasPppoe=<"%~1\RasPppoe.txt") else (set "S_RasPppoe=3")
set "S_RasPppoe=!S_RasPppoe: =!" & set "S_RasPppoe=!S_RasPppoe:0x=!"
if "!S_RasPppoe!"=="" set "S_RasPppoe=3"
reg add "HKLM\SYSTEM\CurrentControlSet\Services\RasPppoe" /v Start /t REG_DWORD /d !S_RasPppoe! /f >nul 2>&1
if exist "%~1\RasSstp.txt" (set /p S_RasSstp=<"%~1\RasSstp.txt") else (set "S_RasSstp=3")
set "S_RasSstp=!S_RasSstp: =!" & set "S_RasSstp=!S_RasSstp:0x=!"
if "!S_RasSstp!"=="" set "S_RasSstp=3"
reg add "HKLM\SYSTEM\CurrentControlSet\Services\RasSstp" /v Start /t REG_DWORD /d !S_RasSstp! /f >nul 2>&1
echo {"success":true,"details":"services restored"}
endlocal & exit /b 0
