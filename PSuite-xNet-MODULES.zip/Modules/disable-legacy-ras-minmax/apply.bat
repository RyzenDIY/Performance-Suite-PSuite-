@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
if not exist "%~1" mkdir "%~1" >nul 2>&1
set "OLD_RasAcd=3"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\RasAcd" /v Start 2^>nul ^| findstr /i "Start"') do set "OLD_RasAcd=%%a"
set "OLD_RasAcd=!OLD_RasAcd: =!" & set "OLD_RasAcd=!OLD_RasAcd:0x=!"
echo !OLD_RasAcd!> "%~1\RasAcd.txt"
sc stop RasAcd >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\RasAcd" /v Start /t REG_DWORD /d 4 /f >nul 2>&1
set "OLD_Rasl2tp=3"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\Rasl2tp" /v Start 2^>nul ^| findstr /i "Start"') do set "OLD_Rasl2tp=%%a"
set "OLD_Rasl2tp=!OLD_Rasl2tp: =!" & set "OLD_Rasl2tp=!OLD_Rasl2tp:0x=!"
echo !OLD_Rasl2tp!> "%~1\Rasl2tp.txt"
sc stop Rasl2tp >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\Rasl2tp" /v Start /t REG_DWORD /d 4 /f >nul 2>&1
set "OLD_RasPppoe=3"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\RasPppoe" /v Start 2^>nul ^| findstr /i "Start"') do set "OLD_RasPppoe=%%a"
set "OLD_RasPppoe=!OLD_RasPppoe: =!" & set "OLD_RasPppoe=!OLD_RasPppoe:0x=!"
echo !OLD_RasPppoe!> "%~1\RasPppoe.txt"
sc stop RasPppoe >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\RasPppoe" /v Start /t REG_DWORD /d 4 /f >nul 2>&1
set "OLD_RasSstp=3"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\RasSstp" /v Start 2^>nul ^| findstr /i "Start"') do set "OLD_RasSstp=%%a"
set "OLD_RasSstp=!OLD_RasSstp: =!" & set "OLD_RasSstp=!OLD_RasSstp:0x=!"
echo !OLD_RasSstp!> "%~1\RasSstp.txt"
sc stop RasSstp >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\RasSstp" /v Start /t REG_DWORD /d 4 /f >nul 2>&1
echo {"success":true,"requiresRestart":false,"details":"services disabled"}
endlocal & exit /b 0
