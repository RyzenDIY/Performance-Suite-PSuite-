@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "OK=1"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\RasAcd" /v Start 2^>nul ^| findstr /i "Start"') do set "ST_RasAcd=%%a"
set "ST_RasAcd=!ST_RasAcd: =!" & set "ST_RasAcd=!ST_RasAcd:0x=!"
if not "!ST_RasAcd!"=="4" set "OK=0"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\Rasl2tp" /v Start 2^>nul ^| findstr /i "Start"') do set "ST_Rasl2tp=%%a"
set "ST_Rasl2tp=!ST_Rasl2tp: =!" & set "ST_Rasl2tp=!ST_Rasl2tp:0x=!"
if not "!ST_Rasl2tp!"=="4" set "OK=0"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\RasPppoe" /v Start 2^>nul ^| findstr /i "Start"') do set "ST_RasPppoe=%%a"
set "ST_RasPppoe=!ST_RasPppoe: =!" & set "ST_RasPppoe=!ST_RasPppoe:0x=!"
if not "!ST_RasPppoe!"=="4" set "OK=0"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\RasSstp" /v Start 2^>nul ^| findstr /i "Start"') do set "ST_RasSstp=%%a"
set "ST_RasSstp=!ST_RasSstp: =!" & set "ST_RasSstp=!ST_RasSstp:0x=!"
if not "!ST_RasSstp!"=="4" set "OK=0"
if "!OK!"=="1" (echo {"success":true,"state":"Applied","details":"all=4"}) else (echo {"success":true,"state":"NotApplied","details":"partial"})
endlocal & exit /b 0
