@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
if not exist "%~1\acc.txt" (echo {"success":false,"details":"Capture not found"} & endlocal & exit /b 0)
for /f "usebackq tokens=1* delims==" %%A in ("%~1\acc.txt") do (
  set "NAME=%%A"
  set "VAL=%%B"
  set "VAL=!VAL: =!"
  set "KEY=HKCU\Control Panel\Accessibility\!NAME!"
  if /i "!VAL!"=="NOT_EXIST" (reg delete "!KEY!" /v Flags /f >nul 2>&1) else (reg add "!KEY!" /v Flags /t REG_SZ /d !VAL! /f >nul 2>&1)
)
echo {"success":true,"details":"Accessibility flags restored"}
endlocal & exit /b 0
