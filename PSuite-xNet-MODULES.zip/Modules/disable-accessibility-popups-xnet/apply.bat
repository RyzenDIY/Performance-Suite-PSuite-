@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
if not exist "%~1" mkdir "%~1" >nul 2>&1
for %%K in (StickyKeys ToggleKeys HighContrast "Keyboard Response" SoundSentry TimeOut) do (
  set "KEY=HKCU\Control Panel\Accessibility\%%~K"
  set "OLD=NOT_EXIST"
  for /f "tokens=3*" %%a in ('reg query "!KEY!" /v Flags 2^>nul ^| findstr /i "Flags"') do set "OLD=%%a"
  echo %%~K=!OLD!>> "%~1\acc.txt"
  reg add "!KEY!" /v Flags /t REG_SZ /d 0 /f >nul 2>&1
)
echo {"success":true,"requiresRestart":false,"details":"Accessibility Flags=0"}
endlocal & exit /b 0
