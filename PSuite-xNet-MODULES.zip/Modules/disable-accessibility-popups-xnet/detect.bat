@echo off
reg query "HKCU\Control Panel\Accessibility\StickyKeys" /v Flags 2>nul | findstr /i "\"0\"" >nul
if not errorlevel 1 (echo {"success":true,"state":"Applied","details":"StickyKeys Flags=0"}) else (echo {"success":true,"state":"NotApplied","details":"other"})
exit /b 0
