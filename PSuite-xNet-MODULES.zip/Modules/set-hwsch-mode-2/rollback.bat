@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
set /p OLD=<"%~1\hwsch.txt"
set "OLD=!OLD: =!"
if /i "!OLD!"=="NOT_EXIST" (reg delete "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v HwSchMode /f >nul 2>&1) else (set "OLD=!OLD:0x=!" & reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v HwSchMode /t REG_DWORD /d !OLD! /f >nul 2>&1)
echo {"success":true,"details":"HwSchMode restored"}
endlocal & exit /b 0
