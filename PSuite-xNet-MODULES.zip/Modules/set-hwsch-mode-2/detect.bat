@echo off
setlocal EnableExtensions EnableDelayedExpansion
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v HwSchMode 2^>nul ^| findstr /i "HwSchMode"') do set "V=%%a"
set "V=!V: =!" & set "V=!V:0x=!"
if "!V!"=="2" (echo {"success":true,"state":"Applied","details":"HwSchMode=2"}) else (echo {"success":true,"state":"NotApplied","details":"HwSchMode=!V!"})
endlocal & exit /b 0
