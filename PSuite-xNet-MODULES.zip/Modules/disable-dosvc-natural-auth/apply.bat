@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
if not exist "%~1" mkdir "%~1" >nul 2>&1
set "OLD_DoSvc=3"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\DoSvc" /v Start 2^>nul ^| findstr /i "Start"') do set "OLD_DoSvc=%%a"
set "OLD_DoSvc=!OLD_DoSvc: =!" & set "OLD_DoSvc=!OLD_DoSvc:0x=!"
echo !OLD_DoSvc!> "%~1\DoSvc.txt"
sc stop DoSvc >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\DoSvc" /v Start /t REG_DWORD /d 4 /f >nul 2>&1
set "OLD_NaturalAuthentication=3"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\NaturalAuthentication" /v Start 2^>nul ^| findstr /i "Start"') do set "OLD_NaturalAuthentication=%%a"
set "OLD_NaturalAuthentication=!OLD_NaturalAuthentication: =!" & set "OLD_NaturalAuthentication=!OLD_NaturalAuthentication:0x=!"
echo !OLD_NaturalAuthentication!> "%~1\NaturalAuthentication.txt"
sc stop NaturalAuthentication >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\NaturalAuthentication" /v Start /t REG_DWORD /d 4 /f >nul 2>&1
echo {"success":true,"requiresRestart":false,"details":"services disabled"}
endlocal & exit /b 0
