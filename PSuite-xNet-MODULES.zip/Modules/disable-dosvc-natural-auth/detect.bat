@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "OK=1"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\DoSvc" /v Start 2^>nul ^| findstr /i "Start"') do set "ST_DoSvc=%%a"
set "ST_DoSvc=!ST_DoSvc: =!" & set "ST_DoSvc=!ST_DoSvc:0x=!"
if not "!ST_DoSvc!"=="4" set "OK=0"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\NaturalAuthentication" /v Start 2^>nul ^| findstr /i "Start"') do set "ST_NaturalAuthentication=%%a"
set "ST_NaturalAuthentication=!ST_NaturalAuthentication: =!" & set "ST_NaturalAuthentication=!ST_NaturalAuthentication:0x=!"
if not "!ST_NaturalAuthentication!"=="4" set "OK=0"
if "!OK!"=="1" (echo {"success":true,"state":"Applied","details":"all=4"}) else (echo {"success":true,"state":"NotApplied","details":"partial"})
endlocal & exit /b 0
