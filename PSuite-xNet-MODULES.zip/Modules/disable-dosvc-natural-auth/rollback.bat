@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
if exist "%~1\DoSvc.txt" (set /p S_DoSvc=<"%~1\DoSvc.txt") else (set "S_DoSvc=3")
set "S_DoSvc=!S_DoSvc: =!" & set "S_DoSvc=!S_DoSvc:0x=!"
if "!S_DoSvc!"=="" set "S_DoSvc=3"
reg add "HKLM\SYSTEM\CurrentControlSet\Services\DoSvc" /v Start /t REG_DWORD /d !S_DoSvc! /f >nul 2>&1
if exist "%~1\NaturalAuthentication.txt" (set /p S_NaturalAuthentication=<"%~1\NaturalAuthentication.txt") else (set "S_NaturalAuthentication=3")
set "S_NaturalAuthentication=!S_NaturalAuthentication: =!" & set "S_NaturalAuthentication=!S_NaturalAuthentication:0x=!"
if "!S_NaturalAuthentication!"=="" set "S_NaturalAuthentication=3"
reg add "HKLM\SYSTEM\CurrentControlSet\Services\NaturalAuthentication" /v Start /t REG_DWORD /d !S_NaturalAuthentication! /f >nul 2>&1
echo {"success":true,"details":"services restored"}
endlocal & exit /b 0
