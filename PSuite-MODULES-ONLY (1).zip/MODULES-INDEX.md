# Modules

| id | name | risk |
|----|------|------|
| `bcd-disable-dynamic-tick` | BCD: disabledynamictick Yes | Experimental |
| `diag-tracking-disable` | Отключение диагностического трекинга (демо) | Safe |
| `disable-83-name-creation` | Отключение 8.3 short names | Advanced |
| `disable-accessibility-popups-xnet` | Accessibility Flags = 0 (xNet) | Safe |
| `disable-active-probing` | Отключение Active Probing | Advanced |
| `disable-alljoyn` | Отключение AllJoyn Router | Safe |
| `disable-assigned-access` | Отключение AssignedAccessManager | Safe |
| `disable-bluetooth-support` | Отключение Bluetooth Support | Advanced |
| `disable-capture-service` | Отключение CaptureService | Advanced |
| `disable-ceip` | Отключение CEIP (Customer Experience Improvement Program) | Safe |
| `disable-delivery-optimization` | Отключение Delivery Optimization | Advanced |
| `disable-diagnostic-policy` | Отключение Diagnostic Policy Service | Advanced |
| `disable-dosvc-natural-auth` | Отключение DoSvc + NaturalAuthentication | Advanced |
| `disable-driver-searching` | Отключение автоматического поиска драйверов | Advanced |
| `disable-error-reporting` | Отключение Windows Error Reporting | Advanced |
| `disable-fax` | Отключение Fax | Safe |
| `disable-filter-keys-hotkey` | Отключение Filter Keys hotkey | Safe |
| `disable-font-cache` | Отключение Font Cache | Experimental |
| `disable-fullscreen-optimizations` | Отключение Fullscreen Optimizations (глобально) | Advanced |
| `disable-function-discovery` | Отключение Function Discovery | Advanced |
| `disable-geolocation` | Отключение службы геолокации | Advanced |
| `disable-gpu-preemption` | Отключение GPU Preemption | Experimental |
| `disable-graphics-perf` | Отключение GraphicsPerfSvc | Advanced |
| `disable-hibernation` | Отключение гибернации | Advanced |
| `disable-hyperv-guest-services` | Отключение Hyper-V guest services | Advanced |
| `disable-icssvc` | Отключение Mobile Hotspot service | Advanced |
| `disable-legacy-ras-minmax` | Отключение legacy RAS miniport drivers | Experimental |
| `disable-maps-broker` | Отключение MapsBroker | Safe |
| `disable-memory-compression` | Отключение Memory Compression | Experimental |
| `disable-mouse-acceleration` | Отключение ускорения мыши | Safe |
| `disable-mouse-shadow` | Отключение тени указателя | Safe |
| `disable-mpo` | Отключение MPO (Multiplane Overlay) | Advanced |
| `disable-network-heuristics` | Отключение Network Heuristics | Advanced |
| `disable-ntfs-last-access` | NTFS Last Access = disabled | Advanced |
| `disable-nvidia-telemetry-tasks` | Отключение NVIDIA scheduled tasks | Safe |
| `disable-offline-files` | Отключение Offline Files | Safe |
| `disable-phone-service` | Отключение Phone Service | Advanced |
| `disable-prefetch` | Отключение Prefetch | Advanced |
| `disable-print-spooler` | Отключение Print Spooler | Advanced |
| `disable-push-to-install` | Отключение PushToInstall | Safe |
| `disable-remote-registry` | Отключение Remote Registry | Safe |
| `disable-retail-demo` | Отключение Retail Demo | Safe |
| `disable-secondary-logon` | Отключение Secondary Logon | Advanced |
| `disable-shared-pc` | Отключение Shared PC account manager | Safe |
| `disable-smart-card` | Отключение Smart Card | Safe |
| `disable-smartcard-stack` | Отключение Smart Card stack | Advanced |
| `disable-sticky-keys-hotkey` | Отключение горячих клавиш Sticky Keys | Safe |
| `disable-sysmain` | Отключение SysMain (Superfetch) | Advanced |
| `disable-toggle-keys-hotkey` | Отключение Toggle Keys hotkey | Safe |
| `disable-touch-keyboard` | Отключение Touch Keyboard service | Advanced |
| `disable-wallet-service` | Отключение WalletService | Safe |
| `disable-widgets` | Отключение Виджетов Windows | Safe |
| `disable-windows-insider` | Отключение Windows Insider Service | Safe |
| `disable-windows-search` | Отключение Windows Search (индексация) | Advanced |
| `disable-work-folders` | Отключение Work Folders | Safe |
| `disable-xbox-services` | Отключение служб Xbox | Advanced |
| `enable-game-mode` | Включение Game Mode | Safe |
| `enable-optimized-power-plan` | План питания Ultimate Performance | Advanced |
| `improve-responsiveness-in-games` | Улучшение отзывчивости в играх | Advanced |
| `make-windows-faster` | Ускорение меню и наведения мыши | Safe |
| `minimize-background-apps` | Ограничение фоновых приложений | Safe |
| `optimize-explorer` | Оптимизация Проводника | Safe |
| `reduce-telemetry-and-services` | Снижение телеметрии и лишних служб | Advanced |
| `reduce-window-transparency` | Отключение прозрачности окон | Safe |
| `restart-explorer` | Перезапуск Проводника | Safe |
| `set-cpu-maximum-performance` | Максимальная производительность процессора | Advanced |
| `set-dpi-map-iommu-contiguous` | DpiMapIommuContiguous = 1 | Experimental |
| `set-gaming-priority-mmcss` | MMCSS Games: Priority High | Advanced |
| `set-hwsch-mode-2` | HwSchMode = 2 (HAGS path) | Advanced |
| `set-menu-show-delay` | MenuShowDelay = 0 | Safe |
| `set-mouse-hover-time` | MouseHoverTime = 10 | Safe |
| `set-network-throttling-index` | Network Throttling Index = 0xFFFFFFFF | Advanced |
| `set-system-responsiveness` | System Responsiveness = 0 | Advanced |
| `set-tcp-ack-frequency` | TcpAckFrequency = 1 | Experimental |
| `set-visual-effects-for-performance` | Визуальные эффекты — производительность | Safe |
| `set-win32-priority-separation` | Win32PrioritySeparation = 26 | Experimental |
| `turn-off-game-bar` | Отключение Game Bar и Game DVR | Safe |
| `turn-off-notifications` | Отключение предложений в уведомлениях | Safe |
| `turn-off-tips-and-suggestions` | Отключение советов и предложений Windows | Safe |

Total: 79
