@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & exit /b 0)
if not exist "%~1" mkdir "%~1" >nul 2>&1
set "OLD=NOT_EXIST"
for /f "tokens=3" %%a in ('reg query "HKCU\Control Panel\Mouse" /v CursorShadow 2^>nul ^| findstr /i "CursorShadow"') do set "OLD=%%a"
echo !OLD!> "%~1\cs.txt"
reg add "HKCU\Control Panel\Mouse" /v CursorShadow /t REG_DWORD /d 0 /f >nul 2>&1
echo {"success":true,"requiresRestart":false,"details":"CursorShadow=0"}
endlocal & exit /b 0
