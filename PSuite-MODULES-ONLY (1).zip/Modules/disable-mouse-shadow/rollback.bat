@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & exit /b 0)
set /p S=<"%~1\cs.txt"
set "S=!S: =!"
if /i "!S!"=="NOT_EXIST" (reg delete "HKCU\Control Panel\Mouse" /v CursorShadow /f >nul 2>&1) else (set "S=!S:0x=!" & reg add "HKCU\Control Panel\Mouse" /v CursorShadow /t REG_DWORD /d !S! /f >nul 2>&1)
echo {"success":true,"details":"restored"}
endlocal & exit /b 0
