@echo off
reg query "HKCU\Control Panel\Mouse" /v CursorShadow 2>nul | findstr /i "0x0" >nul
if not errorlevel 1 (echo {"success":true,"state":"Applied","details":"CursorShadow=0"}) else (echo {"success":true,"state":"NotApplied","details":"on"})
exit /b 0
