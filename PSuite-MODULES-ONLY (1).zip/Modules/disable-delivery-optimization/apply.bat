@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath (%%1) was not provided"} & endlocal & exit /b 0)
set "CapturePath=%~1"
if not exist "%CapturePath%" mkdir "%CapturePath%" >nul 2>&1
set "CAP=%CapturePath%\dosvc.txt"
set "OLD=2"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\DoSvc" /v Start 2^>nul ^| findstr /i "Start"') do set "OLD=%%a"
set "OLD=!OLD: =!"
set "OLD=!OLD:0x=!"
echo !OLD!> "%CAP%"
sc stop DoSvc >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\DoSvc" /v Start /t REG_DWORD /d 4 /f >nul 2>&1
echo {"success":true,"requiresRestart":false,"details":"Delivery Optimization disabled. Previous Start saved."}
endlocal & exit /b 0
