@echo off
setlocal EnableExtensions EnableDelayedExpansion
sc query DoSvc >nul 2>&1
if errorlevel 1 (
  echo {"success":true,"state":"Unknown","details":"Service DoSvc not found"}
  endlocal & exit /b 0
)
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\DoSvc" /v Start 2^>nul ^| findstr /i "Start"') do set "ST=%%a"
set "ST=!ST: =!"
set "ST=!ST:0x=!"
if "!ST!"=="4" (
  echo {"success":true,"state":"Applied","details":"DoSvc Start=4"}
) else (
  echo {"success":true,"state":"NotApplied","details":"DoSvc Start=!ST!"}
)
endlocal & exit /b 0
