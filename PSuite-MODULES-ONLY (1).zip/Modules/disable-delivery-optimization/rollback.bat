@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath (%%1) was not provided"} & endlocal & exit /b 0)
set "CapturePath=%~1"
set "CAP=%CapturePath%\dosvc.txt"
if not exist "%CAP%" (echo {"success":false,"details":"Capture file not found"} & endlocal & exit /b 0)
set /p SAVED=<"%CAP%"
set "SAVED=!SAVED: =!"
set "SAVED=!SAVED:0x=!"
if "!SAVED!"=="" set "SAVED=2"
reg add "HKLM\SYSTEM\CurrentControlSet\Services\DoSvc" /v Start /t REG_DWORD /d !SAVED! /f >nul 2>&1
if not "!SAVED!"=="4" sc start DoSvc >nul 2>&1
echo {"success":true,"details":"DoSvc Start restored to !SAVED!"}
endlocal & exit /b 0
