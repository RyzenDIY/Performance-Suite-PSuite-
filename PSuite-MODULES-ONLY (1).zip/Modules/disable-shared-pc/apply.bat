@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
if not exist "%~1" mkdir "%~1" >nul 2>&1
sc query shpamsvc >nul 2>&1
if errorlevel 1 (echo {"success":true,"requiresRestart":false,"details":"shpamsvc not present"} & endlocal & exit /b 0)
set "OLD=3"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\shpamsvc" /v Start 2^>nul ^| findstr /i "Start"') do set "OLD=%%a"
set "OLD=!OLD: =!" & set "OLD=!OLD:0x=!"
echo !OLD!> "%~1\shpamsvc.txt"
sc stop shpamsvc >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\shpamsvc" /v Start /t REG_DWORD /d 4 /f >nul 2>&1
echo {"success":true,"requiresRestart":false,"details":"shpamsvc disabled"}
endlocal & exit /b 0
