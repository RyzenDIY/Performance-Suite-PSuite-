@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
set "CAP=%~1\prefetch.txt"
if not exist "%CAP%" (echo {"success":false,"details":"Capture not found"} & endlocal & exit /b 0)
set /p SAVED=<"%CAP%"
set "SAVED=!SAVED: =!"
set "SAVED=!SAVED:0x=!"
if "!SAVED!"=="" set "SAVED=3"
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters" /v EnablePrefetcher /t REG_DWORD /d !SAVED! /f >nul 2>&1
echo {"success":true,"details":"Prefetch restored to !SAVED!. Restart recommended."}
endlocal & exit /b 0
