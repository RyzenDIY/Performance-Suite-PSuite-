@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
set "CapturePath=%~1"
if not exist "%CapturePath%" mkdir "%CapturePath%" >nul 2>&1
set "KEY=HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters"
set "OLD=3"
for /f "tokens=3" %%a in ('reg query "%KEY%" /v EnablePrefetcher 2^>nul ^| findstr /i "EnablePrefetcher"') do set "OLD=%%a"
set "OLD=!OLD: =!"
set "OLD=!OLD:0x=!"
echo !OLD!> "%CapturePath%\prefetch.txt"
reg add "%KEY%" /v EnablePrefetcher /t REG_DWORD /d 0 /f >nul 2>&1
echo {"success":true,"requiresRestart":true,"details":"Prefetch disabled. Restart required."}
endlocal & exit /b 0
