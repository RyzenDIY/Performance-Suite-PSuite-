@echo off
setlocal EnableExtensions EnableDelayedExpansion
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters" /v EnablePrefetcher 2^>nul ^| findstr /i "EnablePrefetcher"') do set "V=%%a"
set "V=!V: =!"
set "V=!V:0x=!"
if "!V!"=="0" (echo {"success":true,"state":"Applied","details":"EnablePrefetcher=0"}) else (echo {"success":true,"state":"NotApplied","details":"EnablePrefetcher=!V!"})
endlocal & exit /b 0
