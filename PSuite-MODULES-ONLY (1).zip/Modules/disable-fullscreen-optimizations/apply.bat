@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath (%%1) was not provided"} & endlocal & exit /b 0)
set "CapturePath=%~1"
if not exist "%CapturePath%" mkdir "%CapturePath%" >nul 2>&1
set "CAP=%CapturePath%\fse.txt"
set "OLD=NOT_EXIST"
for /f "tokens=3" %%a in ('reg query "HKCU\System\GameConfigStore" /v "GameDVR_FSEBehaviorMode" 2^>nul ^| findstr /i "GameDVR_FSEBehaviorMode"') do set "OLD=%%a"
echo !OLD!> "%CAP%"
reg add "HKCU\System\GameConfigStore" /v "GameDVR_FSEBehaviorMode" /t REG_DWORD /d 2 /f >nul 2>&1
reg add "HKCU\System\GameConfigStore" /v "GameDVR_HonorUserFSEBehaviorMode" /t REG_DWORD /d 1 /f >nul 2>&1
echo {"success":true,"requiresRestart":false,"details":"Fullscreen Optimizations disabled globally. State saved."}
endlocal & exit /b 0
