@echo off
setlocal EnableExtensions EnableDelayedExpansion
reg query "HKCU\System\GameConfigStore" /v "GameDVR_FSEBehaviorMode" 2>nul | findstr /i "0x2" >nul
if not errorlevel 1 (
  echo {"success":true,"state":"Applied","details":"GameDVR_FSEBehaviorMode=2"}
) else (
  echo {"success":true,"state":"NotApplied","details":"FSE optimizations not disabled"}
)
endlocal & exit /b 0
