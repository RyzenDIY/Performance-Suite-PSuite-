@echo off
setlocal EnableExtensions EnableDelayedExpansion
reg query "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces" /s /v TcpAckFrequency 2>nul | findstr /i "0x1" >nul
if not errorlevel 1 (echo {"success":true,"state":"Applied","details":"TcpAckFrequency=1 found"}) else (echo {"success":true,"state":"NotApplied","details":"No TcpAckFrequency=1"})
endlocal & exit /b 0
