@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
if not exist "%~1" mkdir "%~1" >nul 2>&1
set "CAP=%~1\ack.txt"
if exist "%CAP%" del /f /q "%CAP%" >nul 2>&1
for /f "delims=" %%K in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces" 2^>nul ^| findstr /i "HKEY_"') do (
  set "IF=%%K"
  set "VAL=NOT_EXIST"
  for /f "tokens=3" %%a in ('reg query "!IF!" /v TcpAckFrequency 2^>nul ^| findstr /i "TcpAckFrequency"') do set "VAL=%%a"
  echo !IF!|!VAL!>> "%CAP%"
  reg add "!IF!" /v TcpAckFrequency /t REG_DWORD /d 1 /f >nul 2>&1
)
echo {"success":true,"requiresRestart":false,"details":"TcpAckFrequency=1 set on interfaces"}
endlocal & exit /b 0
