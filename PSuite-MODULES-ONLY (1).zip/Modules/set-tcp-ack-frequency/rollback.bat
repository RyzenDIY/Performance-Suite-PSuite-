@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
set "CAP=%~1\ack.txt"
if not exist "%CAP%" (echo {"success":false,"details":"Capture not found"} & endlocal & exit /b 0)
for /f "usebackq tokens=1* delims=|" %%A in ("%CAP%") do (
  set "IF=%%A"
  set "VAL=%%B"
  set "VAL=!VAL: =!"
  if /i "!VAL!"=="NOT_EXIST" (
    reg delete "!IF!" /v TcpAckFrequency /f >nul 2>&1
  ) else (
    set "VAL=!VAL:0x=!"
    reg add "!IF!" /v TcpAckFrequency /t REG_DWORD /d !VAL! /f >nul 2>&1
  )
)
echo {"success":true,"details":"TcpAckFrequency restored from capture"}
endlocal & exit /b 0
