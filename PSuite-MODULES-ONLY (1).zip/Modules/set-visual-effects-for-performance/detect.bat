@echo off
setlocal EnableExtensions EnableDelayedExpansion
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects" /v "VisualFXSetting" 2>nul | findstr /i "0x2" >nul
if not errorlevel 1 (echo {"success":true,"state":"Applied","details":"VisualFXSetting=2"}) else (echo {"success":true,"state":"NotApplied","details":"VisualFXSetting is not 2"})
endlocal & exit /b 0
