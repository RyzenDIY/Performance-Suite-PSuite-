@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
if not exist "%~1" mkdir "%~1" >nul 2>&1
set "OLD=NOT_EXIST"
for /f "tokens=3*" %%a in ('reg query "HKCU\Control Panel\Accessibility\Keyboard Response" /v Flags 2^>nul ^| findstr /i "Flags"') do set "OLD=%%a"
echo !OLD!> "%~1\val.txt"
reg add "HKCU\Control Panel\Accessibility\Keyboard Response" /v Flags /t REG_SZ /d 122 /f >nul 2>&1
echo {"success":true,"requiresRestart":false,"details":"Flags=122"}
endlocal & exit /b 0
