@echo off
echo {"success":true,"details":"No persistent state to rollback for Explorer restart"}
exit /b 0
