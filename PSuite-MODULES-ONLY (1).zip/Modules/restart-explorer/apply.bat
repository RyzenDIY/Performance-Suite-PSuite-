@echo off
setlocal
if "%~1"=="" (
  echo {"success":false,"details":"CapturePath (%%1) was not provided"}
  endlocal & exit /b 0
)
taskkill /f /im explorer.exe >nul 2>&1
timeout /t 1 /nobreak >nul
start explorer.exe >nul 2>&1
echo {"success":true,"requiresRestart":false,"details":"Explorer restarted"}
endlocal & exit /b 0
