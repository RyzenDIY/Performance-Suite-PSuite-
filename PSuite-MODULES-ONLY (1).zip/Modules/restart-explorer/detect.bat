@echo off
echo {"success":true,"state":"NotApplied","details":"One-shot action. Always NotApplied."}
exit /b 0
