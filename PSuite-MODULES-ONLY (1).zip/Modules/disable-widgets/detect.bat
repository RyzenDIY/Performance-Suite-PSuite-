@echo off
setlocal EnableExtensions EnableDelayedExpansion
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v TaskbarDa 2>nul | findstr /i "0x0" >nul
if not errorlevel 1 (echo {"success":true,"state":"Applied","details":"TaskbarDa=0"}) else (echo {"success":true,"state":"NotApplied","details":"Widgets not disabled"})
endlocal & exit /b 0
