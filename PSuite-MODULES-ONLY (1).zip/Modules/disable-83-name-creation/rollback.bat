@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & exit /b 0)
set /p SAVED=<"%~1\eight.txt"
set "SAVED=!SAVED: =!"
if "!SAVED!"=="" set "SAVED=0"
fsutil behavior set disable8dot3 !SAVED! >nul 2>&1
echo {"success":true,"details":"disable8dot3 restored"}
endlocal & exit /b 0
