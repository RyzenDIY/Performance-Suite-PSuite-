@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & exit /b 0)
if not exist "%~1" mkdir "%~1" >nul 2>&1
set "OLD=0"
for /f "tokens=2 delims=:" %%a in ('fsutil behavior query disable8dot3 2^>nul') do set "OLD=%%a"
set "OLD=!OLD: =!"
echo !OLD!> "%~1\eight.txt"
fsutil behavior set disable8dot3 1 >nul 2>&1
echo {"success":true,"requiresRestart":false,"details":"8.3 names disabled"}
endlocal & exit /b 0
