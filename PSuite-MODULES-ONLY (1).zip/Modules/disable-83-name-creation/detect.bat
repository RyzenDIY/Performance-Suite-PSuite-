@echo off
fsutil behavior query disable8dot3 2>nul | findstr /i "1" >nul
if not errorlevel 1 (echo {"success":true,"state":"Applied","details":"disable8dot3=1"}) else (echo {"success":true,"state":"NotApplied","details":"8.3 enabled or unknown"})
exit /b 0
