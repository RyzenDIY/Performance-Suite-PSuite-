@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
if not exist "%~1" mkdir "%~1" >nul 2>&1
set "KEY=HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile"
set "OLD=NOT_EXIST"
for /f "tokens=3" %%a in ('reg query "%KEY%" /v NetworkThrottlingIndex 2^>nul ^| findstr /i "NetworkThrottlingIndex"') do set "OLD=%%a"
echo !OLD!> "%~1\throttle.txt"
reg add "%KEY%" /v NetworkThrottlingIndex /t REG_DWORD /d 0xffffffff /f >nul 2>&1
echo {"success":true,"requiresRestart":false,"details":"NetworkThrottlingIndex set to 0xFFFFFFFF"}
endlocal & exit /b 0
