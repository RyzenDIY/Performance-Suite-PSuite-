@echo off
setlocal EnableExtensions EnableDelayedExpansion
reg query "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v NetworkThrottlingIndex 2>nul | findstr /i "0xffffffff" >nul
if not errorlevel 1 (echo {"success":true,"state":"Applied","details":"NetworkThrottlingIndex=-1"}) else (echo {"success":true,"state":"NotApplied","details":"Default throttling"})
endlocal & exit /b 0
