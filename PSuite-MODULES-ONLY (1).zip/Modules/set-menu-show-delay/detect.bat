@echo off
setlocal EnableExtensions EnableDelayedExpansion
reg query "HKCU\Control Panel\Desktop" /v MenuShowDelay 2>nul | findstr /i "0x0 \"0\"" >nul
reg query "HKCU\Control Panel\Desktop" /v MenuShowDelay 2>nul | findstr /i "MenuShowDelay" | findstr /r "0$" >nul
if not errorlevel 1 (echo {"success":true,"state":"Applied","details":"MenuShowDelay=0"} & endlocal & exit /b 0)
echo {"success":true,"state":"NotApplied","details":"Default or other delay"}
endlocal & exit /b 0
