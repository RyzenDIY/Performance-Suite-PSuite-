@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
if not exist "%~1" mkdir "%~1" >nul 2>&1
set "OLD=NOT_EXIST"
for /f "tokens=3*" %%a in ('reg query "HKCU\Control Panel\Desktop" /v MenuShowDelay 2^>nul ^| findstr /i "MenuShowDelay"') do set "OLD=%%a"
echo !OLD!> "%~1\menu.txt"
reg add "HKCU\Control Panel\Desktop" /v MenuShowDelay /t REG_SZ /d 0 /f >nul 2>&1
echo {"success":true,"requiresRestart":false,"details":"MenuShowDelay=0"}
endlocal & exit /b 0
