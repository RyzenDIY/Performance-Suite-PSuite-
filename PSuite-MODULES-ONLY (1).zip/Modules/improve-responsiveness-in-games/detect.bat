@echo off
setlocal EnableExtensions EnableDelayedExpansion

set "OK=0"
reg query "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "SystemResponsiveness" 2>nul | findstr /i "0xa" >nul && set /a OK+=1
reg query "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "NetworkThrottlingIndex" 2>nul | findstr /i "0xffffffff" >nul && set /a OK+=1
reg query "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "GPU Priority" 2>nul | findstr /i "0x8" >nul && set /a OK+=1
reg query "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "Priority" 2>nul | findstr /i "0x6" >nul && set /a OK+=1

if !OK! geq 4 (
    echo {"success":true,"state":"Applied","details":"All key values match target"}
    endlocal & exit /b 0
)
if !OK! gtr 0 (
    echo {"success":true,"state":"Partial","details":"!OK! of 4 values applied"}
    endlocal & exit /b 0
)
echo {"success":true,"state":"NotApplied","details":"Default multimedia profile values"}
endlocal & exit /b 0
