@echo off
setlocal EnableExtensions EnableDelayedExpansion

if "%~1"=="" (
    echo {"success":false,"details":"CapturePath (%%1) was not provided"}
    endlocal & exit /b 0
)

set "CapturePath=%~1"
if not exist "%CapturePath%" mkdir "%CapturePath%" >nul 2>&1
set "CAP=%CapturePath%\mmprofile.txt"
set "BASE=HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile"
set "GAMES=%BASE%\Tasks\Games"

(
for %%V in (SystemResponsiveness NetworkThrottlingIndex) do (
    set "VAL=NOT_EXIST"
    for /f "tokens=3" %%a in ('reg query "%BASE%" /v "%%V" 2^>nul ^| findstr /i "%%V"') do set "VAL=%%a"
    echo %%V=!VAL!
)
for %%V in ("GPU Priority" Priority "Scheduling Category" "SFIO Priority") do (
    set "VAL=NOT_EXIST"
    for /f "tokens=3*" %%a in ('reg query "%GAMES%" /v %%V 2^>nul ^| findstr /i %%V') do set "VAL=%%a %%b"
    echo %%~V=!VAL!
)
) > "%CAP%"

reg add "%BASE%" /v "SystemResponsiveness" /t REG_DWORD /d 10 /f >nul 2>&1
reg add "%BASE%" /v "NetworkThrottlingIndex" /t REG_DWORD /d 0xffffffff /f >nul 2>&1
reg add "%GAMES%" /v "GPU Priority" /t REG_DWORD /d 8 /f >nul 2>&1
reg add "%GAMES%" /v "Priority" /t REG_DWORD /d 6 /f >nul 2>&1
reg add "%GAMES%" /v "Scheduling Category" /t REG_SZ /d "High" /f >nul 2>&1
reg add "%GAMES%" /v "SFIO Priority" /t REG_SZ /d "High" /f >nul 2>&1

echo {"success":true,"requiresRestart":false,"details":"Multimedia profile for Games applied. State saved."}
endlocal & exit /b 0
