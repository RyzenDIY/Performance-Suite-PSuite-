@echo off
setlocal EnableExtensions EnableDelayedExpansion

if "%~1"=="" (
    echo {"success":false,"details":"CapturePath (%%1) was not provided"}
    endlocal & exit /b 0
)

set "CapturePath=%~1"
set "CAP=%CapturePath%\mmprofile.txt"
set "BASE=HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile"
set "GAMES=%BASE%\Tasks\Games"

if not exist "%CAP%" (
    echo {"success":false,"details":"Capture file not found"}
    endlocal & exit /b 0
)

for /f "tokens=1,* delims==" %%a in ('type "%CAP%"') do (
    set "NAME=%%a"
    set "VAL=%%b"
    set "VAL=!VAL: =!"
    if /i "!NAME!"=="SystemResponsiveness" (
        if /i "!VAL!"=="NOT_EXIST" (reg delete "%BASE%" /v "SystemResponsiveness" /f >nul 2>&1) else (set "VAL=!VAL:0x=!" & reg add "%BASE%" /v "SystemResponsiveness" /t REG_DWORD /d !VAL! /f >nul 2>&1)
    )
    if /i "!NAME!"=="NetworkThrottlingIndex" (
        if /i "!VAL!"=="NOT_EXIST" (reg delete "%BASE%" /v "NetworkThrottlingIndex" /f >nul 2>&1) else (set "VAL=!VAL:0x=!" & reg add "%BASE%" /v "NetworkThrottlingIndex" /t REG_DWORD /d !VAL! /f >nul 2>&1)
    )
    if /i "!NAME!"=="GPU Priority" (
        if /i "!VAL!"=="NOT_EXIST" (reg delete "%GAMES%" /v "GPU Priority" /f >nul 2>&1) else (set "VAL=!VAL:0x=!" & reg add "%GAMES%" /v "GPU Priority" /t REG_DWORD /d !VAL! /f >nul 2>&1)
    )
    if /i "!NAME!"=="Priority" (
        if /i "!VAL!"=="NOT_EXIST" (reg delete "%GAMES%" /v "Priority" /f >nul 2>&1) else (set "VAL=!VAL:0x=!" & reg add "%GAMES%" /v "Priority" /t REG_DWORD /d !VAL! /f >nul 2>&1)
    )
    if /i "!NAME!"=="Scheduling Category" (
        if /i "!VAL!"=="NOT_EXIST" (reg delete "%GAMES%" /v "Scheduling Category" /f >nul 2>&1) else (reg add "%GAMES%" /v "Scheduling Category" /t REG_SZ /d "!VAL!" /f >nul 2>&1)
    )
    if /i "!NAME!"=="SFIO Priority" (
        if /i "!VAL!"=="NOT_EXIST" (reg delete "%GAMES%" /v "SFIO Priority" /f >nul 2>&1) else (reg add "%GAMES%" /v "SFIO Priority" /t REG_SZ /d "!VAL!" /f >nul 2>&1)
    )
)

echo {"success":true,"details":"Multimedia profile restored from capture"}
endlocal & exit /b 0
