@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath (%%1) was not provided"} & endlocal & exit /b 0)
set "CapturePath=%~1"
if not exist "%CapturePath%" mkdir "%CapturePath%" >nul 2>&1
set "CAP=%CapturePath%\activeprobing.txt"
set "OLD=NOT_EXIST"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\NlaSvc\Parameters\Internet" /v "EnableActiveProbing" 2^>nul ^| findstr /i "EnableActiveProbing"') do set "OLD=%%a"
echo !OLD!> "%CAP%"
reg add "HKLM\SYSTEM\CurrentControlSet\Services\NlaSvc\Parameters\Internet" /v "EnableActiveProbing" /t REG_DWORD /d 0 /f >nul 2>&1
echo {"success":true,"requiresRestart":false,"details":"Active probing disabled. State saved."}
endlocal & exit /b 0
