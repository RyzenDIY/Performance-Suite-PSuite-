@echo off
setlocal EnableExtensions EnableDelayedExpansion
reg query "HKLM\SYSTEM\CurrentControlSet\Services\NlaSvc\Parameters\Internet" /v "EnableActiveProbing" 2>nul | findstr /i "0x0" >nul
if not errorlevel 1 (echo {"success":true,"state":"Applied","details":"EnableActiveProbing=0"}) else (echo {"success":true,"state":"NotApplied","details":"Active probing is enabled"})
endlocal & exit /b 0
