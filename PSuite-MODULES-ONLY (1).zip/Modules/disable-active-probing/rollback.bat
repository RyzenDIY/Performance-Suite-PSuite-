@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath (%%1) was not provided"} & endlocal & exit /b 0)
set "CapturePath=%~1"
set "CAP=%CapturePath%\activeprobing.txt"
if not exist "%CAP%" (echo {"success":false,"details":"Capture file not found"} & endlocal & exit /b 0)
set /p SAVED=<"%CAP%"
set "SAVED=!SAVED: =!"
if /i "!SAVED!"=="NOT_EXIST" (reg delete "HKLM\SYSTEM\CurrentControlSet\Services\NlaSvc\Parameters\Internet" /v "EnableActiveProbing" /f >nul 2>&1) else (set "SAVED=!SAVED:0x=!" & reg add "HKLM\SYSTEM\CurrentControlSet\Services\NlaSvc\Parameters\Internet" /v "EnableActiveProbing" /t REG_DWORD /d !SAVED! /f >nul 2>&1)
echo {"success":true,"details":"Active probing setting restored"}
endlocal & exit /b 0
