@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath (%%1) was not provided"} & endlocal & exit /b 0)
set "CapturePath=%~1"
if not exist "%CapturePath%" mkdir "%CapturePath%" >nul 2>&1
set "CAP=%CapturePath%\wsearch.txt"
set "OLD=2"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\WSearch" /v Start 2^>nul ^| findstr /i "Start"') do set "OLD=%%a"
set "OLD=!OLD: =!"
set "OLD=!OLD:0x=!"
echo !OLD!> "%CAP%"
sc stop WSearch >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\WSearch" /v Start /t REG_DWORD /d 4 /f >nul 2>&1
echo {"success":true,"requiresRestart":false,"details":"Windows Search disabled. Previous Start saved."}
endlocal & exit /b 0
