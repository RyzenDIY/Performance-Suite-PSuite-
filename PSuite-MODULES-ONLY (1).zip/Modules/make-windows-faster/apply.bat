@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath (%%1) was not provided"} & endlocal & exit /b 0)
set "CapturePath=%~1"
if not exist "%CapturePath%" mkdir "%CapturePath%" >nul 2>&1
set "CAP=%CapturePath%\delays.txt"
set "V1=NOT_EXIST" & set "V2=NOT_EXIST"
for /f "tokens=3" %%a in ('reg query "HKCU\Control Panel\Desktop" /v "MenuShowDelay" 2^>nul ^| findstr /i "MenuShowDelay"') do set "V1=%%a"
for /f "tokens=3" %%a in ('reg query "HKCU\Control Panel\Mouse" /v "MouseHoverTime" 2^>nul ^| findstr /i "MouseHoverTime"') do set "V2=%%a"
echo MenuShowDelay=!V1!> "%CAP%"
echo MouseHoverTime=!V2!>> "%CAP%"
reg add "HKCU\Control Panel\Desktop" /v "MenuShowDelay" /t REG_SZ /d "100" /f >nul 2>&1
reg add "HKCU\Control Panel\Mouse" /v "MouseHoverTime" /t REG_SZ /d "100" /f >nul 2>&1
echo {"success":true,"requiresRestart":false,"details":"Menu and hover delays set to 100ms"}
endlocal & exit /b 0
