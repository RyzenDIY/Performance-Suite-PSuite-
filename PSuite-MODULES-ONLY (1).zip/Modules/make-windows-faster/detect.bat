@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "OK=0"
reg query "HKCU\Control Panel\Desktop" /v "MenuShowDelay" 2>nul | findstr /i "100" >nul && set /a OK+=1
reg query "HKCU\Control Panel\Mouse" /v "MouseHoverTime" 2>nul | findstr /i "100" >nul && set /a OK+=1
if !OK! equ 2 (echo {"success":true,"state":"Applied","details":"Both delays set to 100"}) else if !OK! gtr 0 (echo {"success":true,"state":"Partial","details":"!OK! of 2 applied"}) else (echo {"success":true,"state":"NotApplied","details":"Default delays"})
endlocal & exit /b 0
