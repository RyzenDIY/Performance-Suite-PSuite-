@echo off
setlocal EnableExtensions EnableDelayedExpansion

rem CapturePath = %1
rem Restore EXACTLY what was saved. Never invent defaults.

if "%~1"=="" (
    echo {"success":false,"details":"CapturePath (%%1) was not provided"}
    endlocal
    exit /b 0
)

set "CapturePath=%~1"
set "KEY=HKCU\Control Panel\Mouse"
set "CAPTURE_FILE=%CapturePath%\mouse_accel.txt"

if not exist "%CAPTURE_FILE%" (
    echo {"success":false,"details":"Capture file not found. Cannot rollback safely."}
    endlocal
    exit /b 0
)

set "SPEED="
set "TH1="
set "TH2="

for /f "tokens=1,2 delims==" %%a in ('type "%CAPTURE_FILE%"') do (
    if /i "%%a"=="SPEED" set "SPEED=%%b"
    if /i "%%a"=="TH1" set "TH1=%%b"
    if /i "%%a"=="TH2" set "TH2=%%b"
)

if not defined SPEED (
    echo {"success":false,"details":"Invalid capture file format"}
    endlocal
    exit /b 0
)

reg add "%KEY%" /v "MouseSpeed" /t REG_SZ /d "!SPEED!" /f >nul 2>&1
reg add "%KEY%" /v "MouseThreshold1" /t REG_SZ /d "!TH1!" /f >nul 2>&1
reg add "%KEY%" /v "MouseThreshold2" /t REG_SZ /d "!TH2!" /f >nul 2>&1

if errorlevel 1 (
    echo {"success":false,"details":"Failed to restore registry values"}
    endlocal
    exit /b 0
)

echo {"success":true,"details":"Mouse acceleration settings restored (Speed=!SPEED!, TH1=!TH1!, TH2=!TH2!)"}
endlocal
exit /b 0
