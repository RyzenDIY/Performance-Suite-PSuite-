@echo off
setlocal EnableExtensions EnableDelayedExpansion

rem Detect never changes the system.
rem Last non-empty line MUST be valid JSON.

set "KEY=HKCU\Control Panel\Mouse"
set "VAL=MouseSpeed"
set "VAL2=MouseThreshold1"
set "VAL3=MouseThreshold2"

reg query "%KEY%" /v "%VAL%" >nul 2>&1
if errorlevel 1 (
    echo {"success":true,"state":"Unknown","details":"MouseSpeed value not found"}
    endlocal
    exit /b 0
)

set "SPEED="
set "TH1="
set "TH2="

for /f "tokens=3" %%a in ('reg query "%KEY%" /v "%VAL%" 2^>nul ^| findstr /i /c:"%VAL%"') do set "SPEED=%%a"
for /f "tokens=3" %%a in ('reg query "%KEY%" /v "%VAL2%" 2^>nul ^| findstr /i /c:"%VAL2%"') do set "TH1=%%a"
for /f "tokens=3" %%a in ('reg query "%KEY%" /v "%VAL3%" 2^>nul ^| findstr /i /c:"%VAL3%"') do set "TH2=%%a"

set "SPEED=!SPEED: =!"
set "TH1=!TH1: =!"
set "TH2=!TH2: =!"

rem Acceleration is OFF when MouseSpeed=0 and both thresholds=0
if "!SPEED!"=="0" if "!TH1!"=="0" if "!TH2!"=="0" (
    echo {"success":true,"state":"Applied","details":"Mouse acceleration disabled (Speed=0, Thresholds=0)"}
    endlocal
    exit /b 0
)

if "!SPEED!"=="1" (
    echo {"success":true,"state":"NotApplied","details":"Mouse acceleration is enabled (MouseSpeed=1)"}
    endlocal
    exit /b 0
)

echo {"success":true,"state":"Partial","details":"Unexpected values: Speed=!SPEED! TH1=!TH1! TH2=!TH2!"}
endlocal
exit /b 0
