@echo off
setlocal EnableExtensions EnableDelayedExpansion

rem CapturePath comes as first argument (%1)
rem Order: 1) read old state  2) save to CapturePath  3) apply

if "%~1"=="" (
    echo {"success":false,"details":"CapturePath (%%1) was not provided"}
    endlocal
    exit /b 0
)

set "CapturePath=%~1"
if not exist "%CapturePath%" mkdir "%CapturePath%" >nul 2>&1

set "KEY=HKCU\Control Panel\Mouse"
set "CAPTURE_FILE=%CapturePath%\mouse_accel.txt"

rem ========== Capture current values ==========
set "SPEED=1"
set "TH1=6"
set "TH2=10"

for /f "tokens=3" %%a in ('reg query "%KEY%" /v "MouseSpeed" 2^>nul ^| findstr /i /c:"MouseSpeed"') do set "SPEED=%%a"
for /f "tokens=3" %%a in ('reg query "%KEY%" /v "MouseThreshold1" 2^>nul ^| findstr /i /c:"MouseThreshold1"') do set "TH1=%%a"
for /f "tokens=3" %%a in ('reg query "%KEY%" /v "MouseThreshold2" 2^>nul ^| findstr /i /c:"MouseThreshold2"') do set "TH2=%%a"

set "SPEED=!SPEED: =!"
set "TH1=!TH1: =!"
set "TH2=!TH2: =!"

echo SPEED=!SPEED!> "%CAPTURE_FILE%"
echo TH1=!TH1!>> "%CAPTURE_FILE%"
echo TH2=!TH2!>> "%CAPTURE_FILE%"

rem ========== Apply (disable acceleration) ==========
reg add "%KEY%" /v "MouseSpeed" /t REG_SZ /d "0" /f >nul 2>&1
reg add "%KEY%" /v "MouseThreshold1" /t REG_SZ /d "0" /f >nul 2>&1
reg add "%KEY%" /v "MouseThreshold2" /t REG_SZ /d "0" /f >nul 2>&1

if errorlevel 1 (
    echo {"success":false,"details":"Failed to write one or more registry values"}
    endlocal
    exit /b 0
)

echo {"success":true,"requiresRestart":false,"details":"Mouse acceleration disabled. Previous values saved."}
endlocal
exit /b 0
