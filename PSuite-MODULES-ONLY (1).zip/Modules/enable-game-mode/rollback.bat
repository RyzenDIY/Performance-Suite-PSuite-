@echo off
setlocal EnableExtensions EnableDelayedExpansion

if "%~1"=="" (
    echo {"success":false,"details":"CapturePath (%%1) was not provided"}
    endlocal & exit /b 0
)

set "CapturePath=%~1"
set "KEY=HKCU\Software\Microsoft\GameBar"
set "CAP=%CapturePath%\gamemode.txt"

if not exist "%CAP%" (
    echo {"success":false,"details":"Capture file not found"}
    endlocal & exit /b 0
)

set "V1=" & set "V2="
for /f "tokens=1,2 delims==" %%a in ('type "%CAP%"') do (
    if /i "%%a"=="AllowAutoGameMode" set "V1=%%b"
    if /i "%%a"=="AutoGameModeEnabled" set "V2=%%b"
)

if /i "!V1!"=="NOT_EXIST" (
    reg delete "%KEY%" /v "AllowAutoGameMode" /f >nul 2>&1
) else (
    set "V1=!V1:0x=!"
    reg add "%KEY%" /v "AllowAutoGameMode" /t REG_DWORD /d !V1! /f >nul 2>&1
)

if /i "!V2!"=="NOT_EXIST" (
    reg delete "%KEY%" /v "AutoGameModeEnabled" /f >nul 2>&1
) else (
    set "V2=!V2:0x=!"
    reg add "%KEY%" /v "AutoGameModeEnabled" /t REG_DWORD /d !V2! /f >nul 2>&1
)

echo {"success":true,"details":"Game Mode settings restored from capture"}
endlocal & exit /b 0
