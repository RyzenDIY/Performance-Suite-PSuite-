@echo off
setlocal EnableExtensions EnableDelayedExpansion

if "%~1"=="" (
    echo {"success":false,"details":"CapturePath (%%1) was not provided"}
    endlocal & exit /b 0
)

set "CapturePath=%~1"
if not exist "%CapturePath%" mkdir "%CapturePath%" >nul 2>&1

set "KEY=HKCU\Software\Microsoft\GameBar"
set "CAP=%CapturePath%\gamemode.txt"

set "V1=NOT_EXIST" & set "V2=NOT_EXIST"
for /f "tokens=3" %%a in ('reg query "%KEY%" /v "AllowAutoGameMode" 2^>nul ^| findstr /i "AllowAutoGameMode"') do set "V1=%%a"
for /f "tokens=3" %%a in ('reg query "%KEY%" /v "AutoGameModeEnabled" 2^>nul ^| findstr /i "AutoGameModeEnabled"') do set "V2=%%a"

echo AllowAutoGameMode=!V1!> "%CAP%"
echo AutoGameModeEnabled=!V2!>> "%CAP%"

reg add "%KEY%" /v "AllowAutoGameMode" /t REG_DWORD /d 1 /f >nul 2>&1
reg add "%KEY%" /v "AutoGameModeEnabled" /t REG_DWORD /d 1 /f >nul 2>&1

echo {"success":true,"requiresRestart":false,"details":"Game Mode enabled. Previous state saved."}
endlocal & exit /b 0
