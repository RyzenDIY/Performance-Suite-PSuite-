@echo off
setlocal EnableExtensions EnableDelayedExpansion

set "KEY=HKCU\Software\Microsoft\GameBar"

reg query "%KEY%" /v "AllowAutoGameMode" >nul 2>&1
if errorlevel 1 (
    echo {"success":true,"state":"NotApplied","details":"AllowAutoGameMode not found"}
    endlocal & exit /b 0
)

set "V1=" & set "V2="
for /f "tokens=3" %%a in ('reg query "%KEY%" /v "AllowAutoGameMode" 2^>nul ^| findstr /i "AllowAutoGameMode"') do set "V1=%%a"
for /f "tokens=3" %%a in ('reg query "%KEY%" /v "AutoGameModeEnabled" 2^>nul ^| findstr /i "AutoGameModeEnabled"') do set "V2=%%a"

set "V1=!V1:0x=!" & set "V1=!V1: =!"
set "V2=!V2:0x=!" & set "V2=!V2: =!"

if "!V1!"=="1" if "!V2!"=="1" (
    echo {"success":true,"state":"Applied","details":"Game Mode enabled"}
    endlocal & exit /b 0
)

if "!V1!"=="1" (
    echo {"success":true,"state":"Partial","details":"Only AllowAutoGameMode=1"}
    endlocal & exit /b 0
)

echo {"success":true,"state":"NotApplied","details":"Game Mode not fully enabled"}
endlocal & exit /b 0
