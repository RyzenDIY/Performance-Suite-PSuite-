@echo off
setlocal EnableExtensions EnableDelayedExpansion
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\Windows.SystemToast.Suggested" /v "Enabled" 2>nul | findstr /i "0x0" >nul
if not errorlevel 1 (echo {"success":true,"state":"Applied","details":"Suggested notifications disabled"}) else (echo {"success":true,"state":"NotApplied","details":"Suggested notifications not disabled"})
endlocal & exit /b 0
