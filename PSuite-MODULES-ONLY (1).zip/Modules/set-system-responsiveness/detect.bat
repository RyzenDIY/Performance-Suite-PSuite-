@echo off
setlocal EnableExtensions EnableDelayedExpansion
reg query "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v SystemResponsiveness 2>nul | findstr /i "0x0" >nul
if not errorlevel 1 (echo {"success":true,"state":"Applied","details":"SystemResponsiveness=0"}) else (echo {"success":true,"state":"NotApplied","details":"Not zero"})
endlocal & exit /b 0
