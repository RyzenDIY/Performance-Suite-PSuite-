@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
if not exist "%~1" mkdir "%~1" >nul 2>&1
set "KEY=HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile"
set "OLD=NOT_EXIST"
for /f "tokens=3" %%a in ('reg query "%KEY%" /v SystemResponsiveness 2^>nul ^| findstr /i "SystemResponsiveness"') do set "OLD=%%a"
echo !OLD!> "%~1\resp.txt"
reg add "%KEY%" /v SystemResponsiveness /t REG_DWORD /d 0 /f >nul 2>&1
echo {"success":true,"requiresRestart":false,"details":"SystemResponsiveness=0"}
endlocal & exit /b 0
