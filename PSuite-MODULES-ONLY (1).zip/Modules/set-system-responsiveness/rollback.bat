@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
set "CAP=%~1\resp.txt"
if not exist "%CAP%" (echo {"success":false,"details":"Capture not found"} & endlocal & exit /b 0)
set /p SAVED=<"%CAP%"
set "SAVED=!SAVED: =!"
set "KEY=HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile"
if /i "!SAVED!"=="NOT_EXIST" (reg delete "%KEY%" /v SystemResponsiveness /f >nul 2>&1) else (set "SAVED=!SAVED:0x=!" & reg add "%KEY%" /v SystemResponsiveness /t REG_DWORD /d !SAVED! /f >nul 2>&1)
echo {"success":true,"details":"SystemResponsiveness restored"}
endlocal & exit /b 0
