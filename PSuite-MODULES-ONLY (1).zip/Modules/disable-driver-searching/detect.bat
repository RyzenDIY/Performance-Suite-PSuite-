@echo off
setlocal EnableExtensions EnableDelayedExpansion
reg query "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\DriverSearching" /v "SearchOrderConfig" 2>nul | findstr /i "0x0" >nul
if not errorlevel 1 (echo {"success":true,"state":"Applied","details":"SearchOrderConfig=0"}) else (echo {"success":true,"state":"NotApplied","details":"Automatic driver searching is enabled"})
endlocal & exit /b 0
