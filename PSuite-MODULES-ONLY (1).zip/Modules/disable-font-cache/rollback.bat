@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
set "CAP=%~1\FontCache.txt"
if not exist "%CAP%" (echo {"success":false,"details":"Capture not found"} & endlocal & exit /b 0)
set /p SAVED=<"%CAP%"
set "SAVED=!SAVED: =!" & set "SAVED=!SAVED:0x=!"
if "!SAVED!"=="" set "SAVED=2"
reg add "HKLM\SYSTEM\CurrentControlSet\Services\FontCache" /v Start /t REG_DWORD /d !SAVED! /f >nul 2>&1
if not "!SAVED!"=="4" sc start FontCache >nul 2>&1
echo {"success":true,"details":"FontCache restored to !SAVED!"}
endlocal & exit /b 0
