@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
set /p SAVED=<"%~1\icssvc.txt"
set "SAVED=!SAVED: =!" & set "SAVED=!SAVED:0x=!"
if "!SAVED!"=="" set "SAVED=3"
reg add "HKLM\SYSTEM\CurrentControlSet\Services\icssvc" /v Start /t REG_DWORD /d !SAVED! /f >nul 2>&1
echo {"success":true,"details":"restored !SAVED!"}
endlocal & exit /b 0
