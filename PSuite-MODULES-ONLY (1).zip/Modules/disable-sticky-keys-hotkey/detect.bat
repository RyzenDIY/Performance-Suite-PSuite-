@echo off
setlocal EnableExtensions EnableDelayedExpansion
reg query "HKCU\Control Panel\Accessibility\StickyKeys" /v Flags 2>nul | findstr /i "506" >nul
if not errorlevel 1 (echo {"success":true,"state":"Applied","details":"Flags=506"}) else (echo {"success":true,"state":"NotApplied","details":"other"})
endlocal & exit /b 0
