@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
set "CAP=%~1\val.txt"
if not exist "%CAP%" (echo {"success":false,"details":"Capture not found"} & endlocal & exit /b 0)
set /p SAVED=<"%CAP%"
set "SAVED=!SAVED: =!"
if /i "!SAVED!"=="NOT_EXIST" (reg delete "HKCU\Control Panel\Accessibility\StickyKeys" /v Flags /f >nul 2>&1) else (reg add "HKCU\Control Panel\Accessibility\StickyKeys" /v Flags /t REG_SZ /d !SAVED! /f >nul 2>&1)
echo {"success":true,"details":"Flags restored"}
endlocal & exit /b 0
