@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
if not exist "%~1\retail.txt" (echo {"success":false,"details":"Capture not found"} & endlocal & exit /b 0)
set /p SAVED=<"%~1\retail.txt"
set "SAVED=!SAVED: =!" & set "SAVED=!SAVED:0x=!"
if "!SAVED!"=="" set "SAVED=3"
reg add "HKLM\SYSTEM\CurrentControlSet\Services\RetailDemo" /v Start /t REG_DWORD /d !SAVED! /f >nul 2>&1
echo {"success":true,"details":"RetailDemo restored"}
endlocal & exit /b 0
