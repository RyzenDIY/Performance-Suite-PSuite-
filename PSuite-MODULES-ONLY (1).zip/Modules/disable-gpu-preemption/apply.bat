@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath (%%1) was not provided"} & endlocal & exit /b 0)
set "CapturePath=%~1"
if not exist "%CapturePath%" mkdir "%CapturePath%" >nul 2>&1
set "CAP=%CapturePath%\gpupreempt.txt"
set "OLD=NOT_EXIST"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Scheduler" /v "DisablePreemption" 2^>nul ^| findstr /i "DisablePreemption"') do set "OLD=%%a"
echo !OLD!> "%CAP%"
reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Scheduler" /v "DisablePreemption" /t REG_DWORD /d 1 /f >nul 2>&1
echo {"success":true,"requiresRestart":true,"details":"GPU preemption disabled. Restart required."}
endlocal & exit /b 0
