@echo off
setlocal EnableExtensions EnableDelayedExpansion
reg query "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Scheduler" /v "DisablePreemption" 2>nul | findstr /i "0x1" >nul
if not errorlevel 1 (echo {"success":true,"state":"Applied","details":"DisablePreemption=1"}) else (echo {"success":true,"state":"NotApplied","details":"GPU preemption is enabled"})
endlocal & exit /b 0
