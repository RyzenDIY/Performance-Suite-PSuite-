@echo off
setlocal EnableExtensions EnableDelayedExpansion

if "%~1"=="" (
    echo {"success":false,"details":"CapturePath (%%1) was not provided"}
    endlocal & exit /b 0
)

set "CapturePath=%~1"
set "CAP=%CapturePath%\gamebar.txt"

if not exist "%CAP%" (
    echo {"success":false,"details":"Capture file not found"}
    endlocal & exit /b 0
)

set "V1=" & set "V2=" & set "V3="
for /f "tokens=1,2 delims==" %%a in ('type "%CAP%"') do (
    if /i "%%a"=="GameDVR_Enabled" set "V1=%%b"
    if /i "%%a"=="AppCaptureEnabled" set "V2=%%b"
    if /i "%%a"=="AllowGameDVR" set "V3=%%b"
)

if /i "!V1!"=="NOT_EXIST" (reg delete "HKCU\System\GameConfigStore" /v "GameDVR_Enabled" /f >nul 2>&1) else (set "V1=!V1:0x=!" & reg add "HKCU\System\GameConfigStore" /v "GameDVR_Enabled" /t REG_DWORD /d !V1! /f >nul 2>&1)
if /i "!V2!"=="NOT_EXIST" (reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR" /v "AppCaptureEnabled" /f >nul 2>&1) else (set "V2=!V2:0x=!" & reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR" /v "AppCaptureEnabled" /t REG_DWORD /d !V2! /f >nul 2>&1)
if /i "!V3!"=="NOT_EXIST" (reg delete "HKLM\SOFTWARE\Policies\Microsoft\Windows\GameDVR" /v "AllowGameDVR" /f >nul 2>&1) else (set "V3=!V3:0x=!" & reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\GameDVR" /v "AllowGameDVR" /t REG_DWORD /d !V3! /f >nul 2>&1)

echo {"success":true,"details":"Game Bar / Game DVR settings restored"}
endlocal & exit /b 0
