@echo off
setlocal EnableExtensions EnableDelayedExpansion

set "OK=0"

reg query "HKCU\System\GameConfigStore" /v "GameDVR_Enabled" 2>nul | findstr /i "0x0" >nul && set /a OK+=1
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR" /v "AppCaptureEnabled" 2>nul | findstr /i "0x0" >nul && set /a OK+=1
reg query "HKLM\SOFTWARE\Policies\Microsoft\Windows\GameDVR" /v "AllowGameDVR" 2>nul | findstr /i "0x0" >nul && set /a OK+=1

if !OK! equ 3 (
    echo {"success":true,"state":"Applied","details":"Game Bar and Game DVR fully disabled"}
    endlocal & exit /b 0
)
if !OK! gtr 0 (
    echo {"success":true,"state":"Partial","details":"Only !OK! of 3 keys disabled"}
    endlocal & exit /b 0
)

echo {"success":true,"state":"NotApplied","details":"Game Bar / Game DVR still enabled"}
endlocal & exit /b 0
