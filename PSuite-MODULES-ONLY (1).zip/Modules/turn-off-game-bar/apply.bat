@echo off
setlocal EnableExtensions EnableDelayedExpansion

if "%~1"=="" (
    echo {"success":false,"details":"CapturePath (%%1) was not provided"}
    endlocal & exit /b 0
)

set "CapturePath=%~1"
if not exist "%CapturePath%" mkdir "%CapturePath%" >nul 2>&1
set "CAP=%CapturePath%\gamebar.txt"

set "V1=NOT_EXIST" & set "V2=NOT_EXIST" & set "V3=NOT_EXIST"
for /f "tokens=3" %%a in ('reg query "HKCU\System\GameConfigStore" /v "GameDVR_Enabled" 2^>nul ^| findstr /i "GameDVR_Enabled"') do set "V1=%%a"
for /f "tokens=3" %%a in ('reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR" /v "AppCaptureEnabled" 2^>nul ^| findstr /i "AppCaptureEnabled"') do set "V2=%%a"
for /f "tokens=3" %%a in ('reg query "HKLM\SOFTWARE\Policies\Microsoft\Windows\GameDVR" /v "AllowGameDVR" 2^>nul ^| findstr /i "AllowGameDVR"') do set "V3=%%a"

(
echo GameDVR_Enabled=!V1!
echo AppCaptureEnabled=!V2!
echo AllowGameDVR=!V3!
) > "%CAP%"

reg add "HKCU\System\GameConfigStore" /v "GameDVR_Enabled" /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR" /v "AppCaptureEnabled" /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\GameDVR" /v "AllowGameDVR" /t REG_DWORD /d 0 /f >nul 2>&1

echo {"success":true,"requiresRestart":false,"details":"Game Bar and Game DVR disabled. State saved."}
endlocal & exit /b 0
