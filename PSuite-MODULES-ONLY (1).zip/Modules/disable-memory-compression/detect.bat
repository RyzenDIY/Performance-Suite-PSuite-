@echo off
powershell -NoProfile -Command "if ((Get-MMAgent).MemoryCompression -eq $false) { '{"success":true,"state":"Applied","details":"MemoryCompression off"}' } else { '{"success":true,"state":"NotApplied","details":"MemoryCompression on"}' }"
exit /b 0
