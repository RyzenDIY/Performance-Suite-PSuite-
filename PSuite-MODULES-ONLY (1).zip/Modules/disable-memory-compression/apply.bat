@echo off
setlocal
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & exit /b 0)
if not exist "%~1" mkdir "%~1" >nul 2>&1
powershell -NoProfile -Command "(Get-MMAgent).MemoryCompression" > "%~1\mc.txt" 2>nul
powershell -NoProfile -Command "Disable-MMAgent -MemoryCompression" >nul 2>&1
echo {"success":true,"requiresRestart":false,"details":"Memory compression disabled"}
endlocal & exit /b 0
