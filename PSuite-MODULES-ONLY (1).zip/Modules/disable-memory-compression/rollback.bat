@echo off
setlocal
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & exit /b 0)
powershell -NoProfile -Command "Enable-MMAgent -MemoryCompression" >nul 2>&1
echo {"success":true,"details":"Memory compression enabled"}
endlocal & exit /b 0
