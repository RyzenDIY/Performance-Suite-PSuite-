@echo off
setlocal EnableExtensions EnableDelayedExpansion
powercfg /getactivescheme 2>nul | findstr /i "e9a42b02-d5df-448d-aa00-03f14749eb61" >nul
if not errorlevel 1 (echo {"success":true,"state":"Applied","details":"Ultimate Performance is active"}) else (echo {"success":true,"state":"NotApplied","details":"Ultimate Performance is not the active scheme"})
endlocal & exit /b 0
