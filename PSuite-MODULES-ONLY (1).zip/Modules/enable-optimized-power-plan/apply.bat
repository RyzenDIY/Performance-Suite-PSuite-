@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath (%%1) was not provided"} & endlocal & exit /b 0)
set "CapturePath=%~1"
if not exist "%CapturePath%" mkdir "%CapturePath%" >nul 2>&1
set "CAP=%CapturePath%\powerplan.txt"

set "OLD_SCHEME="
for /f "tokens=4" %%a in ('powercfg /getactivescheme 2^>nul') do set "OLD_SCHEME=%%a"
if not defined OLD_SCHEME set "OLD_SCHEME=UNKNOWN"
echo !OLD_SCHEME!> "%CAP%"

powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61 >nul 2>&1
powercfg -setactive e9a42b02-d5df-448d-aa00-03f14749eb61 >nul 2>&1

echo {"success":true,"requiresRestart":false,"details":"Ultimate Performance activated. Previous scheme saved."}
endlocal & exit /b 0
