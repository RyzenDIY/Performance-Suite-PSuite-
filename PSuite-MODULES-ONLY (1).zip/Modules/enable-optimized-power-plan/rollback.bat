@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath (%%1) was not provided"} & endlocal & exit /b 0)
set "CapturePath=%~1"
set "CAP=%CapturePath%\powerplan.txt"
if not exist "%CAP%" (echo {"success":false,"details":"Capture file not found"} & endlocal & exit /b 0)

set /p OLD_SCHEME=<"%CAP%"
set "OLD_SCHEME=!OLD_SCHEME: =!"

if /i "!OLD_SCHEME!"=="UNKNOWN" (
  echo {"success":false,"details":"Previous scheme was unknown"}
  endlocal & exit /b 0
)

powercfg -setactive !OLD_SCHEME! >nul 2>&1
if errorlevel 1 (
  echo {"success":false,"details":"Failed to restore previous power scheme"}
  endlocal & exit /b 0
)

echo {"success":true,"details":"Previous power scheme restored (!OLD_SCHEME!)"}
endlocal & exit /b 0
