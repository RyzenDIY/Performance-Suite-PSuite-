@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "OK=0"
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "LaunchTo" 2>nul | findstr /i "0x1" >nul && set /a OK+=1
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "ShowSyncProviderNotifications" 2>nul | findstr /i "0x0" >nul && set /a OK+=1
if !OK! equ 2 (echo {"success":true,"state":"Applied","details":"Explorer optimized"}) else if !OK! gtr 0 (echo {"success":true,"state":"Partial","details":"!OK! of 2 applied"}) else (echo {"success":true,"state":"NotApplied","details":"Default Explorer settings"})
endlocal & exit /b 0
