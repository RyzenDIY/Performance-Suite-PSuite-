@echo off
setlocal EnableExtensions EnableDelayedExpansion
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v "EnableTransparency" >nul 2>&1
if errorlevel 1 (echo {"success":true,"state":"NotApplied","details":"Value does not exist"} & endlocal & exit /b 0)
set "CURRENT="
for /f "tokens=3" %%a in ('reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v "EnableTransparency" 2^>nul ^| findstr /i "EnableTransparency"') do set "CURRENT=%%a"
set "CURRENT=!CURRENT:0x=!" & set "CURRENT=!CURRENT: =!"
if "!CURRENT!"=="0" (echo {"success":true,"state":"Applied","details":"EnableTransparency=0"}) else if "!CURRENT!"=="1" (echo {"success":true,"state":"NotApplied","details":"EnableTransparency=1"}) else (echo {"success":true,"state":"Partial","details":"Unexpected value: !CURRENT!"})
endlocal & exit /b 0
