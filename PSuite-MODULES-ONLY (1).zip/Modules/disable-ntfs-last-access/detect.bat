@echo off
setlocal
fsutil behavior query disablelastaccess 2>nul | findstr /i "1" >nul
if not errorlevel 1 (echo {"success":true,"state":"Applied","details":"disablelastaccess=1"}) else (echo {"success":true,"state":"NotApplied","details":"enabled or unknown"})
endlocal & exit /b 0
