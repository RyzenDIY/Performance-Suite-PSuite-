@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
set /p SAVED=<"%~1\lastaccess.txt"
set "SAVED=!SAVED: =!"
if "!SAVED!"=="" set "SAVED=0"
fsutil behavior set disablelastaccess !SAVED! >nul 2>&1
echo {"success":true,"details":"disablelastaccess restored to !SAVED!"}
endlocal & exit /b 0
