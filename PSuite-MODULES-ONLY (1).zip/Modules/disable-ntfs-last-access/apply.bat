@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
if not exist "%~1" mkdir "%~1" >nul 2>&1
set "OLD=0"
for /f "tokens=2 delims=:" %%a in ('fsutil behavior query disablelastaccess 2^>nul') do set "OLD=%%a"
set "OLD=!OLD: =!"
echo !OLD!> "%~1\lastaccess.txt"
fsutil behavior set disablelastaccess 1 >nul 2>&1
echo {"success":true,"requiresRestart":false,"details":"NTFS last access disabled"}
endlocal & exit /b 0
