@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath (%%1) was not provided"} & endlocal & exit /b 0)
set "CapturePath=%~1"
if not exist "%CapturePath%" mkdir "%CapturePath%" >nul 2>&1
set "CAP=%CapturePath%\heuristics.txt"
set "OLD=enabled"
netsh int tcp show heuristics 2>nul | findstr /i "disabled" >nul && set "OLD=disabled"
echo !OLD!> "%CAP%"
netsh int tcp set heuristics disabled >nul 2>&1
echo {"success":true,"requiresRestart":false,"details":"Network heuristics disabled. Previous state saved."}
endlocal & exit /b 0
