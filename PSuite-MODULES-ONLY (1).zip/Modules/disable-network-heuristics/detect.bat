@echo off
setlocal EnableExtensions EnableDelayedExpansion
netsh int tcp show heuristics 2>nul | findstr /i "disabled" >nul
if not errorlevel 1 (echo {"success":true,"state":"Applied","details":"Heuristics are disabled"}) else (echo {"success":true,"state":"NotApplied","details":"Heuristics are enabled or unknown"})
endlocal & exit /b 0
