@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath (%%1) was not provided"} & endlocal & exit /b 0)
set "CapturePath=%~1"
set "CAP=%CapturePath%\heuristics.txt"
if not exist "%CAP%" (echo {"success":false,"details":"Capture file not found"} & endlocal & exit /b 0)
set /p SAVED=<"%CAP%"
set "SAVED=!SAVED: =!"
if /i "!SAVED!"=="disabled" (netsh int tcp set heuristics disabled >nul 2>&1) else (netsh int tcp set heuristics enabled >nul 2>&1)
echo {"success":true,"details":"Network heuristics restored to previous state"}
endlocal & exit /b 0
