@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath (%%1) was not provided"} & endlocal & exit /b 0)
set "CapturePath=%~1"
if not exist "%CapturePath%" mkdir "%CapturePath%" >nul 2>&1
set "CAP=%CapturePath%\cpu_perf.txt"

set "SCHEME="
for /f "tokens=4" %%a in ('powercfg /getactivescheme 2^>nul') do set "SCHEME=%%a"
if not defined SCHEME (echo {"success":false,"details":"Could not get active power scheme"} & endlocal & exit /b 0)

set "MIN=UNKNOWN" & set "MAX=UNKNOWN" & set "BOOST=UNKNOWN"
for /f "tokens=2 delims=:" %%a in ('powercfg /query !SCHEME! SUB_PROCESSOR PROCTHROTTLEMIN 2^>nul ^| findstr /i "Current AC Power Setting Index"') do set "MIN=%%a"
for /f "tokens=2 delims=:" %%a in ('powercfg /query !SCHEME! SUB_PROCESSOR PROCTHROTTLEMAX 2^>nul ^| findstr /i "Current AC Power Setting Index"') do set "MAX=%%a"
for /f "tokens=2 delims=:" %%a in ('powercfg /query !SCHEME! SUB_PROCESSOR PERFBOOSTMODE 2^>nul ^| findstr /i "Current AC Power Setting Index"') do set "BOOST=%%a"

(
echo SCHEME=!SCHEME!
echo MIN=!MIN!
echo MAX=!MAX!
echo BOOST=!BOOST!
) > "%CAP%"

powercfg -setacvalueindex !SCHEME! SUB_PROCESSOR PROCTHROTTLEMIN 100 >nul 2>&1
powercfg -setacvalueindex !SCHEME! SUB_PROCESSOR PROCTHROTTLEMAX 100 >nul 2>&1
powercfg -setacvalueindex !SCHEME! SUB_PROCESSOR PERFBOOSTMODE 2 >nul 2>&1
powercfg -setactive !SCHEME! >nul 2>&1

echo {"success":true,"requiresRestart":false,"details":"CPU max performance applied. State saved."}
endlocal & exit /b 0
