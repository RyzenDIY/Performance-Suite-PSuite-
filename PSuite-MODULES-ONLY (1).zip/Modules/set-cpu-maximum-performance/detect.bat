@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "SCHEME="
for /f "tokens=4" %%a in ('powercfg /getactivescheme 2^>nul') do set "SCHEME=%%a"
if not defined SCHEME (echo {"success":true,"state":"Unknown","details":"Could not get active scheme"} & endlocal & exit /b 0)

set "MIN=" & set "MAX=" & set "BOOST="
for /f "tokens=2 delims=:" %%a in ('powercfg /query !SCHEME! SUB_PROCESSOR PROCTHROTTLEMIN 2^>nul ^| findstr /i "Current AC Power Setting Index"') do set "MIN=%%a"
for /f "tokens=2 delims=:" %%a in ('powercfg /query !SCHEME! SUB_PROCESSOR PROCTHROTTLEMAX 2^>nul ^| findstr /i "Current AC Power Setting Index"') do set "MAX=%%a"
for /f "tokens=2 delims=:" %%a in ('powercfg /query !SCHEME! SUB_PROCESSOR PERFBOOSTMODE 2^>nul ^| findstr /i "Current AC Power Setting Index"') do set "BOOST=%%a"

set "MIN=!MIN: =!" & set "MAX=!MAX: =!" & set "BOOST=!BOOST: =!"
set "MIN=!MIN:0x=!" & set "MAX=!MAX:0x=!" & set "BOOST=!BOOST:0x=!"

if "!MIN!"=="00000064" if "!MAX!"=="00000064" if "!BOOST!"=="00000002" (
  echo {"success":true,"state":"Applied","details":"CPU set to max performance"}
) else (
  echo {"success":true,"state":"NotApplied","details":"MIN=!MIN! MAX=!MAX! BOOST=!BOOST!"}
)
endlocal & exit /b 0
