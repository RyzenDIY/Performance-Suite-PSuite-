@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath (%%1) was not provided"} & endlocal & exit /b 0)
set "CapturePath=%~1"
set "CAP=%CapturePath%\cpu_perf.txt"
if not exist "%CAP%" (echo {"success":false,"details":"Capture file not found"} & endlocal & exit /b 0)

set "SCHEME=" & set "MIN=" & set "MAX=" & set "BOOST="
for /f "tokens=1,2 delims==" %%a in ('type "%CAP%"') do (
  if /i "%%a"=="SCHEME" set "SCHEME=%%b"
  if /i "%%a"=="MIN" set "MIN=%%b"
  if /i "%%a"=="MAX" set "MAX=%%b"
  if /i "%%a"=="BOOST" set "BOOST=%%b"
)

set "SCHEME=!SCHEME: =!" & set "MIN=!MIN: =!" & set "MAX=!MAX: =!" & set "BOOST=!BOOST: =!"
set "MIN=!MIN:0x=!" & set "MAX=!MAX:0x=!" & set "BOOST=!BOOST:0x=!"

if not defined SCHEME (echo {"success":false,"details":"Scheme not found in capture"} & endlocal & exit /b 0)

if not "!MIN!"=="UNKNOWN" (powercfg -setacvalueindex !SCHEME! SUB_PROCESSOR PROCTHROTTLEMIN 0x!MIN! >nul 2>&1)
if not "!MAX!"=="UNKNOWN" (powercfg -setacvalueindex !SCHEME! SUB_PROCESSOR PROCTHROTTLEMAX 0x!MAX! >nul 2>&1)
if not "!BOOST!"=="UNKNOWN" (powercfg -setacvalueindex !SCHEME! SUB_PROCESSOR PERFBOOSTMODE 0x!BOOST! >nul 2>&1)
powercfg -setactive !SCHEME! >nul 2>&1

echo {"success":true,"details":"CPU performance settings restored"}
endlocal & exit /b 0
