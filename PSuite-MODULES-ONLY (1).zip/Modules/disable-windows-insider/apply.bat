@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
if not exist "%~1" mkdir "%~1" >nul 2>&1
sc query wisvc >nul 2>&1
if errorlevel 1 (echo {"success":true,"requiresRestart":false,"details":"wisvc not present"} & endlocal & exit /b 0)
set "OLD=3"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\wisvc" /v Start 2^>nul ^| findstr /i "Start"') do set "OLD=%%a"
set "OLD=!OLD: =!" & set "OLD=!OLD:0x=!"
echo !OLD!> "%~1\wisvc.txt"
sc stop wisvc >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\wisvc" /v Start /t REG_DWORD /d 4 /f >nul 2>&1
echo {"success":true,"requiresRestart":false,"details":"wisvc disabled"}
endlocal & exit /b 0
