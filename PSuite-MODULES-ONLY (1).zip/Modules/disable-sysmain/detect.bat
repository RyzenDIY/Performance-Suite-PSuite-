@echo off
setlocal EnableExtensions EnableDelayedExpansion
sc query SysMain >nul 2>&1
if errorlevel 1 (
  echo {"success":true,"state":"Unknown","details":"Service SysMain not found"}
  endlocal & exit /b 0
)
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\SysMain" /v Start 2^>nul ^| findstr /i "Start"') do set "ST=%%a"
set "ST=!ST: =!"
set "ST=!ST:0x=!"
if "!ST!"=="4" (
  echo {"success":true,"state":"Applied","details":"SysMain Start=4 (Disabled)"}
) else (
  echo {"success":true,"state":"NotApplied","details":"SysMain Start=!ST!"}
)
endlocal & exit /b 0
