@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath (%%1) was not provided"} & endlocal & exit /b 0)
set "CapturePath=%~1"
if not exist "%CapturePath%" mkdir "%CapturePath%" >nul 2>&1
set "CAP=%CapturePath%\sysmain.txt"
set "OLD=3"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\SysMain" /v Start 2^>nul ^| findstr /i "Start"') do set "OLD=%%a"
set "OLD=!OLD: =!"
set "OLD=!OLD:0x=!"
echo !OLD!> "%CAP%"
sc stop SysMain >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\SysMain" /v Start /t REG_DWORD /d 4 /f >nul 2>&1
if errorlevel 1 (
  echo {"success":false,"details":"Failed to set SysMain Start=4"}
  endlocal & exit /b 0
)
echo {"success":true,"requiresRestart":false,"details":"SysMain disabled (Start=4). Previous Start saved."}
endlocal & exit /b 0
