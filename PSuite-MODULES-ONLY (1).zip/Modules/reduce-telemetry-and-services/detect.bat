@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "OK=0"
for %%S in (DiagTrack dmwappushservice MapsBroker) do (
  sc qc %%S 2>nul | findstr /i "START_TYPE.*DEMAND_START" >nul && set /a OK+=1
)
if !OK! equ 3 (echo {"success":true,"state":"Applied","details":"All 3 services set to demand"}) else if !OK! gtr 0 (echo {"success":true,"state":"Partial","details":"!OK! of 3 services set to demand"}) else (echo {"success":true,"state":"NotApplied","details":"Services not in demand start"})
endlocal & exit /b 0
