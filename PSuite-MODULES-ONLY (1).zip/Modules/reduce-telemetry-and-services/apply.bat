@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath (%%1) was not provided"} & endlocal & exit /b 0)
set "CapturePath=%~1"
if not exist "%CapturePath%" mkdir "%CapturePath%" >nul 2>&1
set "CAP=%CapturePath%\services_telemetry.txt"

(
for %%S in (DiagTrack dmwappushservice MapsBroker) do (
  set "START=UNKNOWN"
  for /f "tokens=3" %%a in ('sc qc %%S 2^>nul ^| findstr /i "START_TYPE"') do set "START=%%a"
  echo %%S=!START!
)
) > "%CAP%"

for %%S in (DiagTrack dmwappushservice MapsBroker) do (
  sc stop %%S >nul 2>&1
  sc config %%S start= demand >nul 2>&1
)

echo {"success":true,"requiresRestart":false,"details":"Telemetry services set to demand. State saved."}
endlocal & exit /b 0
