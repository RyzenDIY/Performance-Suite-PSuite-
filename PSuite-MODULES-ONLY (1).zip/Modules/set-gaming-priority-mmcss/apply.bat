@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
if not exist "%~1" mkdir "%~1" >nul 2>&1
set "KEY=HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games"
set "P=NOT_EXIST" & set "G=NOT_EXIST" & set "S=NOT_EXIST" & set "C=NOT_EXIST"
for /f "tokens=3" %%a in ('reg query "%KEY%" /v Priority 2^>nul ^| findstr /i "Priority"') do set "P=%%a"
for /f "tokens=3*" %%a in ('reg query "%KEY%" /v "GPU Priority" 2^>nul ^| findstr /i "GPU"') do set "G=%%a"
for /f "tokens=3*" %%a in ('reg query "%KEY%" /v "Scheduling Category" 2^>nul ^| findstr /i "Scheduling"') do set "S=%%b"
for /f "tokens=3*" %%a in ('reg query "%KEY%" /v "SFIO Priority" 2^>nul ^| findstr /i "SFIO"') do set "C=%%b"
(
echo Priority=!P!
echo GPUPriority=!G!
echo SchedulingCategory=!S!
echo SFIOPriority=!C!
) > "%~1\mmcss.txt"
reg add "%KEY%" /v "Priority" /t REG_DWORD /d 6 /f >nul 2>&1
reg add "%KEY%" /v "GPU Priority" /t REG_DWORD /d 8 /f >nul 2>&1
reg add "%KEY%" /v "Scheduling Category" /t REG_SZ /d "High" /f >nul 2>&1
reg add "%KEY%" /v "SFIO Priority" /t REG_SZ /d "High" /f >nul 2>&1
echo {"success":true,"requiresRestart":false,"details":"Games MMCSS priority set to High"}
endlocal & exit /b 0
