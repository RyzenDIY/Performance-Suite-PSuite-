@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
set "CAP=%~1\mmcss.txt"
if not exist "%CAP%" (echo {"success":false,"details":"Capture not found"} & endlocal & exit /b 0)
set "KEY=HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games"
for /f "tokens=1* delims==" %%a in ('type "%CAP%"') do (
  set "N=%%a" & set "V=%%b"
  if /i "!N!"=="Priority" if /i not "!V!"=="NOT_EXIST" (
    set "V=!V: =!" & set "V=!V:0x=!"
    reg add "%KEY%" /v Priority /t REG_DWORD /d !V! /f >nul 2>&1
  )
)
echo {"success":true,"details":"Games MMCSS priority restored from capture"}
endlocal & exit /b 0
