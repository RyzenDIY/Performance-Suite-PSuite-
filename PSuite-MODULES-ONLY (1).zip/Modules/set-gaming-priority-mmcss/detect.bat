@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "KEY=HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games"
reg query "%KEY%" /v Priority 2>nul | findstr /i "0x6" >nul
if not errorlevel 1 (echo {"success":true,"state":"Applied","details":"Games Priority=6"}) else (echo {"success":true,"state":"NotApplied","details":"Default Games MMCSS"})
endlocal & exit /b 0
