@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "OK=0"
for %%S in (XblAuthManager XblGameSave XboxGipSvc XboxNetApiSvc) do (
  sc qc %%S 2>nul | findstr /i "START_TYPE.*DEMAND_START" >nul && set /a OK+=1
)
if !OK! equ 4 (echo {"success":true,"state":"Applied","details":"All 4 Xbox services set to demand"}) else if !OK! gtr 0 (echo {"success":true,"state":"Partial","details":"!OK! of 4 services set to demand"}) else (echo {"success":true,"state":"NotApplied","details":"Xbox services not restricted"})
endlocal & exit /b 0
