@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath (%%1) was not provided"} & endlocal & exit /b 0)
set "CapturePath=%~1"
set "CAP=%CapturePath%\xbox_services.txt"
if not exist "%CAP%" (echo {"success":false,"details":"Capture file not found"} & endlocal & exit /b 0)

for /f "tokens=1,2 delims==" %%a in ('type "%CAP%"') do (
  set "SVC=%%a"
  set "START=%%b"
  set "START=!START: =!"
  if /i "!START!"=="2" (sc config !SVC! start= auto >nul 2>&1)
  if /i "!START!"=="3" (sc config !SVC! start= demand >nul 2>&1)
  if /i "!START!"=="4" (sc config !SVC! start= disabled >nul 2>&1)
  if /i "!START!"=="AUTO_START" (sc config !SVC! start= auto >nul 2>&1)
  if /i "!START!"=="DEMAND_START" (sc config !SVC! start= demand >nul 2>&1)
  if /i "!START!"=="DISABLED" (sc config !SVC! start= disabled >nul 2>&1)
)

echo {"success":true,"details":"Xbox services start types restored"}
endlocal & exit /b 0
