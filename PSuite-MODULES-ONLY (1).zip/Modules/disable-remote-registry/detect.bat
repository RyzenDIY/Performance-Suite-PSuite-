@echo off
setlocal EnableExtensions EnableDelayedExpansion
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\RemoteRegistry" /v Start 2^>nul ^| findstr /i "Start"') do set "ST=%%a"
set "ST=!ST: =!" & set "ST=!ST:0x=!"
if "!ST!"=="4" (echo {"success":true,"state":"Applied","details":"RemoteRegistry=4"}) else (echo {"success":true,"state":"NotApplied","details":"Start=!ST!"})
endlocal & exit /b 0
