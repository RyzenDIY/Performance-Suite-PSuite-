@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
set "CAP=%~1\remotereg.txt"
if not exist "%CAP%" (echo {"success":false,"details":"Capture not found"} & endlocal & exit /b 0)
set /p SAVED=<"%CAP%"
set "SAVED=!SAVED: =!" & set "SAVED=!SAVED:0x=!"
if "!SAVED!"=="" set "SAVED=4"
reg add "HKLM\SYSTEM\CurrentControlSet\Services\RemoteRegistry" /v Start /t REG_DWORD /d !SAVED! /f >nul 2>&1
echo {"success":true,"details":"RemoteRegistry restored to !SAVED!"}
endlocal & exit /b 0
