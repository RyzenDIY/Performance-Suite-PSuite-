@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
if not exist "%~1" mkdir "%~1" >nul 2>&1
set "KEY=HKLM\SYSTEM\CurrentControlSet\Control\PriorityControl"
set "OLD=NOT_EXIST"
for /f "tokens=3" %%a in ('reg query "%KEY%" /v Win32PrioritySeparation 2^>nul ^| findstr /i "Win32PrioritySeparation"') do set "OLD=%%a"
echo !OLD!> "%~1\w32ps.txt"
reg add "%KEY%" /v Win32PrioritySeparation /t REG_DWORD /d 0x26 /f >nul 2>&1
echo {"success":true,"requiresRestart":true,"details":"Win32PrioritySeparation=0x26. Restart required."}
endlocal & exit /b 0
