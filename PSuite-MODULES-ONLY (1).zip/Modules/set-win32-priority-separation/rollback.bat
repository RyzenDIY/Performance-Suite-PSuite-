@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
set "CAP=%~1\w32ps.txt"
if not exist "%CAP%" (echo {"success":false,"details":"Capture not found"} & endlocal & exit /b 0)
set /p SAVED=<"%CAP%"
set "SAVED=!SAVED: =!"
set "KEY=HKLM\SYSTEM\CurrentControlSet\Control\PriorityControl"
if /i "!SAVED!"=="NOT_EXIST" (reg delete "%KEY%" /v Win32PrioritySeparation /f >nul 2>&1) else (set "SAVED=!SAVED:0x=!" & reg add "%KEY%" /v Win32PrioritySeparation /t REG_DWORD /d !SAVED! /f >nul 2>&1)
echo {"success":true,"details":"Win32PrioritySeparation restored. Restart recommended."}
endlocal & exit /b 0
