@echo off
setlocal EnableExtensions EnableDelayedExpansion
reg query "HKLM\SYSTEM\CurrentControlSet\Control\PriorityControl" /v Win32PrioritySeparation 2>nul | findstr /i "0x26" >nul
if not errorlevel 1 (echo {"success":true,"state":"Applied","details":"Win32PrioritySeparation=0x26"}) else (echo {"success":true,"state":"NotApplied","details":"Other value"})
endlocal & exit /b 0
