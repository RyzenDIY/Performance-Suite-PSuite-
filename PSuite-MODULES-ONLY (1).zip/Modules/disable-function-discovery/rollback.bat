@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
set /p A=<"%~1\fdrespub.txt"
set /p B=<"%~1\fdphost.txt"
set "A=!A: =!" & set "A=!A:0x=!" & set "B=!B: =!" & set "B=!B:0x=!"
if "!A!"=="" set "A=3"
if "!B!"=="" set "B=3"
reg add "HKLM\SYSTEM\CurrentControlSet\Services\FDResPub" /v Start /t REG_DWORD /d !A! /f >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\fdPHost" /v Start /t REG_DWORD /d !B! /f >nul 2>&1
echo {"success":true,"details":"Function Discovery restored"}
endlocal & exit /b 0
