@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "A=0" & set "B=0"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\FDResPub" /v Start 2^>nul ^| findstr /i "Start"') do set "A=%%a"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\fdPHost" /v Start 2^>nul ^| findstr /i "Start"') do set "B=%%a"
set "A=!A: =!" & set "A=!A:0x=!" & set "B=!B: =!" & set "B=!B:0x=!"
if "!A!"=="4" if "!B!"=="4" (echo {"success":true,"state":"Applied","details":"FDResPub+fdPHost=4"} & endlocal & exit /b 0)
echo {"success":true,"state":"NotApplied","details":"FDResPub=!A! fdPHost=!B!"}
endlocal & exit /b 0
