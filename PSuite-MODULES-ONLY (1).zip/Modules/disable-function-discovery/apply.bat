@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
if not exist "%~1" mkdir "%~1" >nul 2>&1
set "A=3" & set "B=3"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\FDResPub" /v Start 2^>nul ^| findstr /i "Start"') do set "A=%%a"
for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\fdPHost" /v Start 2^>nul ^| findstr /i "Start"') do set "B=%%a"
set "A=!A: =!" & set "A=!A:0x=!" & set "B=!B: =!" & set "B=!B:0x=!"
echo !A!> "%~1\fdrespub.txt"
echo !B!> "%~1\fdphost.txt"
sc stop FDResPub >nul 2>&1
sc stop fdPHost >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\FDResPub" /v Start /t REG_DWORD /d 4 /f >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\fdPHost" /v Start /t REG_DWORD /d 4 /f >nul 2>&1
echo {"success":true,"requiresRestart":false,"details":"Function Discovery services disabled"}
endlocal & exit /b 0
