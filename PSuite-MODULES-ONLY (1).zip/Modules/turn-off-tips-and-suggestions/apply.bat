@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath (%%1) was not provided"} & endlocal & exit /b 0)
set "CapturePath=%~1"
if not exist "%CapturePath%" mkdir "%CapturePath%" >nul 2>&1
set "CAP=%CapturePath%\tips.txt"
set "V1=NOT_EXIST" & set "V2=NOT_EXIST" & set "V3=NOT_EXIST"
for /f "tokens=3" %%a in ('reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-338389Enabled" 2^>nul ^| findstr /i "338389"') do set "V1=%%a"
for /f "tokens=3" %%a in ('reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-353698Enabled" 2^>nul ^| findstr /i "353698"') do set "V2=%%a"
for /f "tokens=3" %%a in ('reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SystemPaneSuggestionsEnabled" 2^>nul ^| findstr /i "SystemPaneSuggestionsEnabled"') do set "V3=%%a"
echo SubscribedContent-338389Enabled=!V1!> "%CAP%"
echo SubscribedContent-353698Enabled=!V2!>> "%CAP%"
echo SystemPaneSuggestionsEnabled=!V3!>> "%CAP%"
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-338389Enabled" /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-353698Enabled" /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SystemPaneSuggestionsEnabled" /t REG_DWORD /d 0 /f >nul 2>&1
echo {"success":true,"requiresRestart":false,"details":"Tips and suggestions disabled. State saved."}
endlocal & exit /b 0
