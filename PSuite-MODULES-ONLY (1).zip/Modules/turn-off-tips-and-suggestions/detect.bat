@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "OK=0"
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-338389Enabled" 2>nul | findstr /i "0x0" >nul && set /a OK+=1
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-353698Enabled" 2>nul | findstr /i "0x0" >nul && set /a OK+=1
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SystemPaneSuggestionsEnabled" 2>nul | findstr /i "0x0" >nul && set /a OK+=1
if !OK! equ 3 (echo {"success":true,"state":"Applied","details":"Tips and suggestions disabled"}) else if !OK! gtr 0 (echo {"success":true,"state":"Partial","details":"!OK! of 3 applied"}) else (echo {"success":true,"state":"NotApplied","details":"Tips still enabled"})
endlocal & exit /b 0
