@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath (%%1) was not provided"} & endlocal & exit /b 0)
set "CapturePath=%~1"
set "CAP=%CapturePath%\tips.txt"
if not exist "%CAP%" (echo {"success":false,"details":"Capture file not found"} & endlocal & exit /b 0)
for /f "tokens=1,2 delims==" %%a in ('type "%CAP%"') do (
  set "NAME=%%a" & set "VAL=%%b" & set "VAL=!VAL: =!"
  if /i "!NAME!"=="SubscribedContent-338389Enabled" (
    if /i "!VAL!"=="NOT_EXIST" (reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-338389Enabled" /f >nul 2>&1) else (set "VAL=!VAL:0x=!" & reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-338389Enabled" /t REG_DWORD /d !VAL! /f >nul 2>&1)
  )
  if /i "!NAME!"=="SubscribedContent-353698Enabled" (
    if /i "!VAL!"=="NOT_EXIST" (reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-353698Enabled" /f >nul 2>&1) else (set "VAL=!VAL:0x=!" & reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-353698Enabled" /t REG_DWORD /d !VAL! /f >nul 2>&1)
  )
  if /i "!NAME!"=="SystemPaneSuggestionsEnabled" (
    if /i "!VAL!"=="NOT_EXIST" (reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SystemPaneSuggestionsEnabled" /f >nul 2>&1) else (set "VAL=!VAL:0x=!" & reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SystemPaneSuggestionsEnabled" /t REG_DWORD /d !VAL! /f >nul 2>&1)
  )
)
echo {"success":true,"details":"Tips and suggestions restored"}
endlocal & exit /b 0
