@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath (%%1) was not provided"} & endlocal & exit /b 0)
set "CapturePath=%~1"
if not exist "%CapturePath%" mkdir "%CapturePath%" >nul 2>&1
set "CAP=%CapturePath%\mpo.txt"
set "OLD=NOT_EXIST"
for /f "tokens=3" %%a in ('reg query "HKLM\SOFTWARE\Microsoft\Windows\Dwm" /v "OverlayTestMode" 2^>nul ^| findstr /i "OverlayTestMode"') do set "OLD=%%a"
echo !OLD!> "%CAP%"
reg add "HKLM\SOFTWARE\Microsoft\Windows\Dwm" /v "OverlayTestMode" /t REG_DWORD /d 5 /f >nul 2>&1
echo {"success":true,"requiresRestart":true,"details":"MPO disabled (OverlayTestMode=5). Restart required."}
endlocal & exit /b 0
