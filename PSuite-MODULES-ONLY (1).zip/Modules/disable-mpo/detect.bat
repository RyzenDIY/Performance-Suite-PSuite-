@echo off
setlocal EnableExtensions EnableDelayedExpansion
reg query "HKLM\SOFTWARE\Microsoft\Windows\Dwm" /v "OverlayTestMode" 2>nul | findstr /i "0x5" >nul
if not errorlevel 1 (echo {"success":true,"state":"Applied","details":"OverlayTestMode=5"}) else (echo {"success":true,"state":"NotApplied","details":"MPO not disabled"})
endlocal & exit /b 0
