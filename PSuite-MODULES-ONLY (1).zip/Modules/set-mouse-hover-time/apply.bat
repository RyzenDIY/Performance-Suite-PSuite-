@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
if not exist "%~1" mkdir "%~1" >nul 2>&1
set "OLD=NOT_EXIST"
for /f "tokens=3*" %%a in ('reg query "HKCU\Control Panel\Mouse" /v MouseHoverTime 2^>nul ^| findstr /i "MouseHoverTime"') do set "OLD=%%a"
echo !OLD!> "%~1\hover.txt"
reg add "HKCU\Control Panel\Mouse" /v MouseHoverTime /t REG_SZ /d 10 /f >nul 2>&1
echo {"success":true,"requiresRestart":false,"details":"MouseHoverTime=10"}
endlocal & exit /b 0
