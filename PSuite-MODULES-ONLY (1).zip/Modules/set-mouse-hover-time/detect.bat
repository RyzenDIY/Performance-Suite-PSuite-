@echo off
setlocal EnableExtensions EnableDelayedExpansion
reg query "HKCU\Control Panel\Mouse" /v MouseHoverTime 2>nul | findstr /i "10" >nul
if not errorlevel 1 (echo {"success":true,"state":"Applied","details":"MouseHoverTime=10"}) else (echo {"success":true,"state":"NotApplied","details":"Other value"})
endlocal & exit /b 0
