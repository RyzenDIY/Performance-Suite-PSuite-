@echo off
setlocal EnableExtensions EnableDelayedExpansion
reg query "HKLM\SYSTEM\CurrentControlSet\Control\Power" /v HibernateEnabled 2>nul | findstr /i "0x0" >nul
if not errorlevel 1 (echo {"success":true,"state":"Applied","details":"HibernateEnabled=0"}) else (echo {"success":true,"state":"NotApplied","details":"Hibernation enabled or unknown"})
endlocal & exit /b 0
