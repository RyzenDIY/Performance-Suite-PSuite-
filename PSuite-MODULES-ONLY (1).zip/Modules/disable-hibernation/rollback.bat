@echo off
setlocal EnableExtensions EnableDelayedExpansion
if "%~1"=="" (echo {"success":false,"details":"CapturePath missing"} & endlocal & exit /b 0)
set "CAP=%~1\hibernate.txt"
if not exist "%CAP%" (echo {"success":false,"details":"Capture not found"} & endlocal & exit /b 0)
set /p SAVED=<"%CAP%"
set "SAVED=!SAVED: =!"
if /i "!SAVED!"=="NOT_EXIST" (
  reg delete "HKLM\SYSTEM\CurrentControlSet\Control\Power" /v HibernateEnabled /f >nul 2>&1
) else (
  set "SAVED=!SAVED:0x=!"
  reg add "HKLM\SYSTEM\CurrentControlSet\Control\Power" /v HibernateEnabled /t REG_DWORD /d !SAVED! /f >nul 2>&1
)
if /i not "!SAVED!"=="0" powercfg /h on >nul 2>&1
echo {"success":true,"details":"Hibernation setting restored"}
endlocal & exit /b 0
